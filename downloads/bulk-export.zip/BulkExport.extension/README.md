# Bulk Export (pyRevit extension)

Batch-export sheets to PDF / DWG / DWF / IFC / Images in one pass, with a
ProSheets-style dialog: paper size, orientation, placement, zoom, hide
options, and a token-based file naming format.

This is a **standalone extension**, separate from ABS Tools / ECD_Tools -
it adds its own **Batch Export** ribbon tab and doesn't touch your
existing extension.

## Install

1. Copy the whole `BulkExport.extension` folder to your pyRevit
   extensions directory, e.g.:
   `%APPDATA%\pyRevit\Extensions\BulkExport.extension`
2. In Revit: **pyRevit tab > Settings > Reload** (or restart Revit).
3. You'll get a new **Batch Export** ribbon tab with an **Export**
   panel and a **Bulk Export** button (icon included).

## What's real vs. limited (please read before relying on this)

Revit's public API does not treat all these formats equally:

| Format | Support | Notes |
|---|---|---|
| PDF | Full, per-sheet | Uses `PDFExportOptions`. Paper size, orientation, placement, zoom, hide-line options, raster quality, and color mode all map to real API properties. |
| DWG | Full, per-sheet | Uses `DWGExportOptions`. Layer mapping / line-weight table export settings are left at your Revit DWG export defaults - extend `_export_dwg()` if you keep a custom export setup. |
| DWF | Full, per-sheet | Same pattern as DWG. |
| Images | Per-sheet, name approximate | Revit auto-suffixes the file name when exporting a "set of views," so the exact token-built name isn't 100% guaranteed - see the comment in `_export_image()`. |
| IFC | Whole model only | IFC export is not per-sheet in the Revit API. One IFC file is produced per run, named from the project number. |
| NWC | Whole model / 3D view only, and **requires the separate Navisworks Exporter for Revit add-in** | The API class `NavisworksExportOptions` only exists if that add-in is installed. If it's missing, the tool tells you rather than failing silently. |
| DGN | **Not available** | Revit has no public API class for DGN export - it's UI-only (File > Export > CAD Formats > DGN). The checkbox is disabled in the UI for this reason. |

## DWG Export Setup

The Format tab's DWG panel now reads the actual DWG export setups already
saved in your Revit model (Manage tab > Export Setups > DWG/DXF) and lets
you pick one from a dropdown, same as Revit's native export dialog.
Picking `<Default Revit Settings>` uses a plain `DWGExportOptions()`
instead. The "Export views on sheets and links as external references"
checkbox maps to `DWGExportOptions.MergedViews` (VERIFY the exact meaning
on your Revit version - property names here have shifted slightly across
releases).

## Profiles (shareable XML settings)

The header bar's **Profile** controls let you save/reuse a full settings
snapshot (formats, paper setup, hide options, DWG setup choice, file
naming, output folder, etc.) as an XML file:

- **Profile dropdown + `+` / Save / Del** - a personal library stored at
  `%APPDATA%\BulkExportTools\Profiles\*.xml` on your machine. Picking a
  profile from the dropdown loads it immediately.
- **Import...** - load an XML file a teammate sent you (Teams, email,
  shared drive - anywhere). You'll be offered the option to also save it
  into your local profile list for quick reuse afterward.
- **Export...** - save your current settings to an XML file anywhere you
  choose, so you can hand it to your team.

The XML is plain text and portable - safe to check into a shared folder
alongside your project template.

## UI layout

The tool is now organized like a small wizard: **Selection** (sheet
list) > **Format** (format checkboxes; the settings panel below changes
automatically based on which formats you've ticked - PDF settings only
appear when PDF is checked, DWG's Export Setup picker only appears when
DWG is checked, etc.) > **Create** (file naming + output folder +
Export). The footer always shows how many sheets are selected and has
the Export/Close/About buttons.

## File naming - "Edit filename" builder

Click **Edit filename** next to the Custom Filename box to open a
parameter picker (same idea as ProSheets' filename dialog):

- **Available Parameters** - every parameter found across your sheets,
  plus (optionally) Project Information parameters via the checkbox above
  the list.
- **Selected Parameters** - the fields that make up the file name, in
  order. Add with the ▶ button, remove with ◀.
- **Field Separator** - when checked, the character in the box (default
  `-`) is inserted automatically between two consecutive parameter
  fields. It is NOT inserted next to custom/literal entries (like a `(`
  or `)` you add yourself), so `Sheet Number-Sheet Name(Current
  Revision)` is achievable.
- **Custom Field** - adds literal text (e.g. a fixed word) at the current
  position.
- **Custom Separator** - quick way to drop in a literal character like
  `(`, `)`, `_`, `-` between two fields without it being auto-spaced.
- Reorder with the ▲/▼ (and top/bottom) buttons; the ↻ button clears the
  list.
- **Ok** bakes your selection into the naming pattern used at export
  time; **Cancel** discards changes.

Default naming (before you touch anything): `Project Number-Sheet
Number-Sheet Name`.

## 3D view / whole-model export switch

**Enable 3D view export (NWC)** is OFF by default. PDF/DWG/DWF/IMG only
ever touch the sheets you tick in the Sheets list - they never pull in a
3D view. The NWC checkbox itself is disabled until you turn this switch
on, and even if NWC is ticked, the export is skipped (and reported in the
summary) unless the switch is on. This is a deliberate double-gate so a
whole-model NWC export can't happen by accident.

## About

Click **About** in the bottom-right of the tool for developer/contact
info (Sri Ram, sreeram14092002@gmail.com) - also shown in the footer of
the main window.


## Things worth verifying on your Revit version before a production run

A handful of API details vary slightly by Revit release (2021 vs 2024 vs
2025, etc.) - the same caution you already apply to shared parameter IDs
in ABS Tools:

- `PDFExportOptions.UserDefinedMarginX/Y` units (assumed inches here -
  double-check against your version's API help).
- `ExportPaperFormat` enum member names (a couple of paper sizes were
  renamed across versions).
- `NavisworksExportOptions.ExportScope` enum values.

Run a small test batch (2-3 sheets, one format) into a scratch folder
before pointing this at a real deliverable folder.
