# -*- coding: utf-8 -*-
"""
Bulk Export - Scheduled/unattended export entry point
--------------------------------------------------------
This is NOT a pyRevit ribbon button. It's meant to be run headlessly via
the pyRevit CLI, driven by Windows Task Scheduler, e.g.:

    pyrevit run "C:\...\BulkExport.extension\lib\scheduled_export.py" "C:\...\MyModel.rvt"

See README.md -> "Scheduled / unattended exports" for full setup steps
(the .bat file to create, and how to wire up Task Scheduler).

No dialogs, no popups - if something goes wrong, it's written to a log
file instead of shown on screen, since nobody is there to click "OK" on
a 3am export run.

CONFIGURE THIS RUN:
Edit scheduled_export_config.json (same folder as this script) to pick
which saved profile to use and which sheets to include. Any profile you
saved from the normal Bulk Export button (Profile bar -> Save) works
here directly - this script just loads that same .xml file.
"""

import os
import sys
import json
import datetime
import traceback

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import bulk_export_core as core

from Autodesk.Revit.DB import FilteredElementCollector, ViewSheet, View3D
from pyrevit import revit, script

logger = script.get_logger()

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(THIS_DIR, 'scheduled_export_config.json')
LOG_DIR = os.path.join(
    os.environ.get('APPDATA', os.path.expanduser('~')),
    'BulkExportTools', 'Logs')
PROFILES_DIR = os.path.join(
    os.environ.get('APPDATA', os.path.expanduser('~')),
    'BulkExportTools', 'Profiles')


def load_config():
    default_config = {
        'profile_name': '',
        'sheet_filter': 'ALL',
        'output_folder_override': ''
    }
    if not os.path.isfile(CONFIG_PATH):
        return default_config
    try:
        with open(CONFIG_PATH, 'r') as f:
            user_config = json.load(f)
        default_config.update(user_config)
    except Exception as ex:
        logger.error('Could not read scheduled_export_config.json: {0}'.format(ex))
    return default_config


def load_profile_settings(profile_name):
    path = os.path.join(PROFILES_DIR, profile_name + '.xml')
    if not os.path.isfile(path):
        raise Exception('Profile "{0}" not found at {1}. Save it from the Bulk Export '
                         'button first (Profile bar -> name it -> Save).'.format(profile_name, path))
    with open(path, 'rb') as f:
        xml_text = f.read()
    profile = core.xml_string_to_profile(xml_text)
    profile['naming_tokens'] = core.bake_tokens(
        profile['naming_entries'], profile['naming_sep_enabled'], profile['naming_sep_char'])
    return profile


def select_sheets(document, sheet_filter):
    all_sheets = list(FilteredElementCollector(document).OfClass(ViewSheet).ToElements())
    all_sheets.sort(key=lambda s: s.SheetNumber)

    if not sheet_filter or sheet_filter.strip().upper() == 'ALL':
        return all_sheets

    prefixes = [p.strip() for p in sheet_filter.split(',') if p.strip()]
    return [s for s in all_sheets if any(s.SheetNumber.startswith(p) for p in prefixes)]


def write_log(lines):
    core.ensure_dir(LOG_DIR)
    stamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    log_path = os.path.join(LOG_DIR, 'scheduled_export_{0}.log'.format(stamp))
    try:
        with open(log_path, 'w') as f:
            f.write('\n'.join(lines))
    except Exception as ex:
        logger.error('Could not write log file: {0}'.format(ex))
    return log_path


def main():
    log_lines = []

    def log(msg):
        stamped = '[{0}] {1}'.format(datetime.datetime.now().strftime('%H:%M:%S'), msg)
        log_lines.append(stamped)
        logger.info(stamped)

    log('Scheduled Bulk Export starting.')

    try:
        config = load_config()
        log('Config: {0}'.format(config))

        if not config.get('profile_name'):
            raise Exception('scheduled_export_config.json has no "profile_name" set. '
                             'Edit that file next to scheduled_export.py first.')

        doc = revit.doc
        if doc is None:
            raise Exception('No active document - pyrevit run should have opened the target model.')
        log('Active document: {0}'.format(doc.Title))

        settings = load_profile_settings(config['profile_name'])
        log('Loaded profile "{0}".'.format(config['profile_name']))

        if config.get('output_folder_override'):
            settings['output_folder'] = config['output_folder_override']

        if not settings.get('output_folder'):
            raise Exception('Profile has no output folder set, and no '
                             'output_folder_override given in the config.')
        core.ensure_dir(settings['output_folder'])

        sheets = select_sheets(doc, config.get('sheet_filter', 'ALL'))
        log('{0} sheet(s) selected (filter: {1}).'.format(len(sheets), config.get('sheet_filter', 'ALL')))

        if not sheets and any(settings['formats'].get(k) for k in ('pdf', 'dwg', 'dwf', 'img')):
            raise Exception('No sheets matched the configured filter - nothing to export '
                             'for the per-sheet formats.')

        dwg_setups = core.get_dwg_export_setups(doc)
        view3d_list = [v for v in FilteredElementCollector(doc).OfClass(View3D).ToElements()
                        if not v.IsTemplate]

        results = core.run_export_batch(
            doc, sheets, settings, dwg_setups, view3d_list,
            log=logger,
            on_progress=lambda status, frac: log('{0} ({1:.0%})'.format(status, frac))
        )

        ok_count = sum(1 for r in results if r[0])
        fail_count = len(results) - ok_count
        log('Done. {0} succeeded, {1} failed/skipped, {2} total.'.format(ok_count, fail_count, len(results)))
        for ok, name, err in results:
            if not ok:
                log('  FAILED: {0} - {1}'.format(name, err))

    except Exception as ex:
        log('FATAL ERROR: {0}'.format(ex))
        log(traceback.format_exc())

    finally:
        log_path = write_log(log_lines)
        logger.info('Log written to {0}'.format(log_path))


if __name__ == '__main__':
    main()
