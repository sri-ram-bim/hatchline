# -*- coding: utf-8 -*-
"""
Bulk Export - shared core logic
---------------------------------
Everything here is UI-independent: it never touches a WPF control. Both
the interactive "Bulk Export" pushbutton and the headless "Scheduled
Export" pushbutton import from this single file, so a fix made here
benefits both instead of needing to be duplicated and kept in sync by
hand.

This file lives in the extension's top-level `lib/` folder, which
pyRevit automatically adds to sys.path for every bundle inside this
extension - so any script.py in this extension can just do:
    import bulk_export_core as core

Developed by: Sri Ram
Contact: sreeram14092002@gmail.com
"""

import os
import re
import xml.etree.ElementTree as ET

import clr
clr.AddReference('RevitAPI')

from Autodesk.Revit.DB import (
    FilteredElementCollector, ViewSheet, BuiltInParameter,
    ElementId, StorageType
)

# --- PDF ---
from Autodesk.Revit.DB import (
    PDFExportOptions, ExportPaperFormat, PageOrientationType,
    PaperPlacementType, ZoomFitType, RasterQualityType, ColorDepthType,
    MarginType
)
try:
    # Confirmed via a real crash report: some Revit versions (2027 seen
    # so far) want a distinct "ZoomType" enum for this property instead
    # of ZoomFitType, even though both have identical member names
    # (.FitToPage, .Zoom). Try both at runtime rather than guessing.
    from Autodesk.Revit.DB import ZoomType as _ZoomTypeEnum
    HAS_ZOOMTYPE_ENUM = True
except ImportError:
    HAS_ZOOMTYPE_ENUM = False
    _ZoomTypeEnum = None
# --- DWG / DWF ---
from Autodesk.Revit.DB import DWGExportOptions
try:
    from Autodesk.Revit.DB import ExportDWGSettings
    HAS_DWG_SETUPS = True
except ImportError:
    HAS_DWG_SETUPS = False
try:
    HAS_DWFX = False
    from Autodesk.Revit.DB import DWFExportOptions
    try:
        from Autodesk.Revit.DB import DWFXExportOptions
        HAS_DWFX = True
    except ImportError:
        HAS_DWFX = False
    HAS_DWF = True
except ImportError:
    HAS_DWF = False
# --- IFC ---
try:
    from Autodesk.Revit.DB.IFC import IFCExportOptions
    HAS_IFC = True
except ImportError:
    HAS_IFC = False
# --- Images ---
from Autodesk.Revit.DB import (
    ImageExportOptions, ExportRange, ImageFileType, ImageResolution,
    FitDirectionType
)
# --- NWC (requires the separate "Navisworks Exporter for Revit" add-in) ---
try:
    from Autodesk.Revit.DB import NavisworksExportOptions, NavisworksCoordinates, NavisworksExportScope
    HAS_NWC = True
except ImportError:
    HAS_NWC = False

import System

DEFAULT_DWG_LABEL = '<Default Revit Settings>'

DEFAULT_NAMING_ENTRIES = [
    {'type': 'param', 'value': 'Project Number'},
    {'type': 'param', 'value': 'Sheet Number'},
    {'type': 'param', 'value': 'Sheet Name'},
]
DEFAULT_SEPARATOR_ENABLED = True
DEFAULT_SEPARATOR_CHAR = '-'

PAPER_FORMAT_MAP = {
    'ISO A0': 'ISO_A0', 'ISO A1': 'ISO_A1', 'ISO A2': 'ISO_A2',
    'ISO A3': 'ISO_A3', 'ISO A4': 'ISO_A4',
    'ANSI A': 'ANSI_A', 'ANSI B': 'ANSI_B', 'ANSI C': 'ANSI_C',
    'ANSI D': 'ANSI_D', 'ANSI E': 'ANSI_E',
    'Arch D': 'ARCH_D', 'Arch E': 'ARCH_E',
}


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def mm_to_inch(mm_value):
    try:
        return float(mm_value) / 25.4
    except (TypeError, ValueError):
        return 0.0


def sanitize_filename(name):
    """Strip characters that are illegal in Windows file names."""
    return re.sub(r'[\\/:*?"<>|]', '_', name).strip()


def clean_pcp_file(output_folder, base_name, log=None):
    """Revit's DWG exporter sometimes leaves a .pcp (plot config) file
    alongside the .dwg. Deletes it if present. Real, working file cleanup -
    unlike "Bind Images as OLE", this needs no external application."""
    pcp_path = os.path.join(output_folder, base_name + '.pcp')
    if os.path.isfile(pcp_path):
        try:
            os.remove(pcp_path)
            return True
        except Exception as ex:
            if log:
                log.warn('Could not delete .pcp file "{0}": {1}'.format(pcp_path, ex))
    return False


def get_project_number(document):
    proj_info = document.ProjectInformation
    try:
        return proj_info.get_Parameter(BuiltInParameter.PROJECT_NUMBER).AsString() or ''
    except Exception:
        return ''


def get_current_revision_number(document, sheet):
    try:
        rev_id = sheet.GetCurrentRevision()
        if rev_id and rev_id != ElementId.InvalidElementId:
            rev = document.GetElement(rev_id)
            param = rev.get_Parameter(BuiltInParameter.PROJECT_REVISION_REVISION_NUM)
            if param:
                return param.AsString() or ''
    except Exception:
        pass
    return ''


def ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass


def try_set_attr(obj, attr_name, value, label=None, log=None):
    """Best-effort setattr - a number of export option properties vary or
    don't exist across Revit versions/formats. Logs a warning and
    continues instead of aborting the whole export over one missing or
    renamed property."""
    try:
        setattr(obj, attr_name, value)
        return True
    except Exception as ex:
        if log:
            log.warn('Skipped "{0}" ({1}.{2}): {3}'.format(
                label or attr_name, type(obj).__name__, attr_name, ex))
        return False


def try_set_enum_attr(obj, attr_name, member_name, candidate_enums, label=None, log=None):
    """Some Revit properties expect a different (but identically-named-
    member) enum TYPE depending on Revit version - confirmed for the
    .ZoomType property, which wants ZoomFitType on some versions and a
    separate ZoomType enum on others (same .FitToPage/.Zoom members,
    different underlying .NET type). Tries each candidate enum in turn
    and keeps the first one that actually works."""
    last_ex = None
    for enum_type in candidate_enums:
        if enum_type is None:
            continue
        try:
            value = getattr(enum_type, member_name)
        except Exception as ex:
            last_ex = ex
            continue
        try:
            setattr(obj, attr_name, value)
            return True
        except Exception as ex:
            last_ex = ex
            continue
    if log:
        log.warn('Skipped "{0}" ({1}.{2}) - tried {3} enum candidate(s), none worked: {4}'.format(
            label or attr_name, type(obj).__name__, attr_name, len(candidate_enums), last_ex))
    return False


_ZOOM_ENUM_CANDIDATES = [ZoomFitType, _ZoomTypeEnum] if HAS_ZOOMTYPE_ENUM else [ZoomFitType]


# ---------------------------------------------------------------------------
# Parameter discovery + value lookup (drives the "Edit filename" builder,
# and the naming pattern used at export time)
# ---------------------------------------------------------------------------

def get_all_sheet_parameter_names(document):
    names = set(['Sheet Number', 'Sheet Name', 'Current Revision'])
    try:
        for sh in FilteredElementCollector(document).OfClass(ViewSheet).ToElements():
            for p in sh.Parameters:
                try:
                    names.add(p.Definition.Name)
                except Exception:
                    pass
    except Exception:
        pass
    return sorted(names)


def get_project_info_parameter_names(document):
    names = set()
    try:
        for p in document.ProjectInformation.Parameters:
            try:
                names.add(p.Definition.Name)
            except Exception:
                pass
    except Exception:
        pass
    return sorted(names)


def get_param_value_by_name(document, sheet, name):
    special_getters = {
        'Sheet Number': lambda: sheet.SheetNumber,
        'Sheet Name': lambda: sheet.Name,
        'Current Revision': lambda: get_current_revision_number(document, sheet),
    }
    getter = special_getters.get(name)
    if getter:
        try:
            val = getter()
            if val:
                return val
        except Exception:
            pass

    p = sheet.LookupParameter(name)
    if p is None:
        try:
            p = document.ProjectInformation.LookupParameter(name)
        except Exception:
            p = None
    if p is None:
        return ''

    try:
        if p.StorageType == StorageType.String:
            return p.AsString() or ''
        elif p.StorageType == StorageType.Integer:
            return str(p.AsInteger())
        elif p.StorageType == StorageType.Double:
            return p.AsValueString() or str(p.AsDouble())
        elif p.StorageType == StorageType.ElementId:
            eid = p.AsElementId()
            if eid and eid != ElementId.InvalidElementId:
                el = document.GetElement(eid)
                return el.Name if el and hasattr(el, 'Name') else str(eid.IntegerValue)
            return ''
    except Exception:
        pass
    return ''


def bake_tokens(entries, sep_enabled, sep_char):
    """Insert the field separator between two consecutive PARAMETER entries
    only - literal entries (like manually-added '(' ')' or custom text) sit
    exactly where you put them, matching the 'Edit filename' dialog."""
    tokens = []
    prev_type = None
    for e in entries:
        if e['type'] == 'param':
            if sep_enabled and prev_type == 'param' and sep_char:
                tokens.append({'type': 'literal', 'value': sep_char})
            tokens.append({'type': 'param', 'key': e['value']})
            prev_type = 'param'
        else:
            tokens.append({'type': 'literal', 'value': e['value']})
            prev_type = 'literal'
    return tokens


def build_filename_from_tokens(document, tokens, sheet):
    parts = []
    for tok in tokens:
        if tok['type'] == 'param':
            parts.append(get_param_value_by_name(document, sheet, tok['key']) or '')
        else:
            parts.append(tok['value'])
    return sanitize_filename(''.join(parts))


# ---------------------------------------------------------------------------
# DWG export setups (real, saved-in-model setups - Manage tab > Export
# Setups > DWG/DXF)
# ---------------------------------------------------------------------------

def get_dwg_export_setups(document):
    """Returns {display_name: ExportDWGSettings element}."""
    setups = {}
    if not HAS_DWG_SETUPS:
        return setups
    try:
        for el in FilteredElementCollector(document).OfClass(ExportDWGSettings).ToElements():
            try:
                setups[el.Name] = el
            except Exception:
                pass
    except Exception:
        pass
    return setups


# ---------------------------------------------------------------------------
# Profile serialization (shareable XML settings files - also used to feed
# the headless Scheduled Export script)
# ---------------------------------------------------------------------------

def _xml_set(parent, tag, value):
    el = ET.SubElement(parent, tag)
    el.text = '' if value is None else str(value)
    return el


def profile_to_xml_string(profile):
    root = ET.Element('BulkExportProfile')
    root.set('version', '1')

    fmts = ET.SubElement(root, 'Formats')
    for key, val in profile['formats'].items():
        _xml_set(fmts, key, 'true' if val else 'false')

    _xml_set(root, 'EnableEnable3D', profile['enable_3d'])
    _xml_set(root, 'PaperSize', profile['paper_size'])
    _xml_set(root, 'Orientation', profile['orientation'])
    _xml_set(root, 'PlacementCenter', profile['placement_center'])
    _xml_set(root, 'OffsetX', profile['offset_x_mm'])
    _xml_set(root, 'OffsetY', profile['offset_y_mm'])
    _xml_set(root, 'ZoomFit', profile['zoom_fit'])
    _xml_set(root, 'ZoomPct', profile['zoom_pct'])
    _xml_set(root, 'VectorProcessing', profile['vector_processing'])
    _xml_set(root, 'RasterQuality', profile['raster_quality'])
    _xml_set(root, 'Colors', profile['colors'])
    _xml_set(root, 'ViewLinksBlue', profile['view_links_blue'])
    _xml_set(root, 'HideRefPlanes', profile['hide_ref_planes'])
    _xml_set(root, 'HideUnrefTags', profile['hide_unref_tags'])
    _xml_set(root, 'HideScopeBoxes', profile['hide_scope_boxes'])
    _xml_set(root, 'HideCropBoundaries', profile['hide_crop_boundaries'])
    _xml_set(root, 'DwgSetupName', profile['dwg_setup_name'])
    _xml_set(root, 'DwgXrefs', profile['dwg_xrefs'])
    _xml_set(root, 'DwgCleanPcp', profile.get('dwg_clean_pcp', False))
    _xml_set(root, 'SeparateFiles', profile['separate_files'])
    _xml_set(root, 'OutputFolder', profile['output_folder'])
    _xml_set(root, 'View3DName', profile['view3d_name'])
    _xml_set(root, 'NamingSepEnabled', profile['naming_sep_enabled'])
    _xml_set(root, 'NamingSepChar', profile['naming_sep_char'])

    _xml_set(root, 'DwfIsDwfx', profile.get('dwf_is_dwfx', False))
    _xml_set(root, 'DwfCropbox', profile.get('dwf_cropbox', False))
    _xml_set(root, 'DwfExportObjectData', profile.get('dwf_export_object_data', False))
    _xml_set(root, 'DwfExportAreas', profile.get('dwf_export_areas', False))
    _xml_set(root, 'DwfExportTextures', profile.get('dwf_export_textures', False))
    _xml_set(root, 'DwfXrefs', profile.get('dwf_xrefs', False))
    _xml_set(root, 'DwfImageQuality', profile.get('dwf_image_quality', 'High'))

    _xml_set(root, 'NwcCoordinates', profile.get('nwc_coordinates', 'Shared'))
    _xml_set(root, 'NwcDivideLevels', profile.get('nwc_divide_levels', True))
    _xml_set(root, 'NwcExportLinks', profile.get('nwc_export_links', False))
    _xml_set(root, 'NwcExportRoomGeometry', profile.get('nwc_export_room_geometry', True))
    _xml_set(root, 'NwcFacetingFactor', profile.get('nwc_faceting_factor', '1'))

    _xml_set(root, 'ImgFitToPixels', profile.get('img_fit_to_pixels', True))
    _xml_set(root, 'ImgPixels', profile.get('img_pixels', '2048'))
    _xml_set(root, 'ImgDirection', profile.get('img_direction', 'Horizontal'))
    _xml_set(root, 'ImgZoomPct', profile.get('img_zoom_pct', '50'))
    _xml_set(root, 'ImgShadedFormat', profile.get('img_shaded_format', 'PNG'))
    _xml_set(root, 'ImgNonShadedFormat', profile.get('img_nonshaded_format', 'PNG'))
    _xml_set(root, 'ImgDpi', profile.get('img_dpi', 'DPI_72'))

    # Scheduled/unattended-export specific fields (harmless no-ops for the
    # interactive GUI, which ignores unknown profile fields).
    _xml_set(root, 'SheetNumberFilter', profile.get('sheet_number_filter', ''))
    _xml_set(root, 'DatedSubfolder', profile.get('dated_subfolder', True))

    entries_el = ET.SubElement(root, 'NamingEntries')
    for e in profile['naming_entries']:
        entry_el = ET.SubElement(entries_el, 'Entry')
        entry_el.set('type', e['type'])
        entry_el.set('value', e['value'])

    return ET.tostring(root, encoding='utf-8')


def _to_bool(text, default=False):
    if text is None:
        return default
    return text.strip().lower() == 'true'


def xml_string_to_profile(xml_text):
    root = ET.fromstring(xml_text)
    profile = {}

    fmts = {}
    fmts_el = root.find('Formats')
    if fmts_el is not None:
        for key in ('pdf', 'dwg', 'dwf', 'nwc', 'ifc', 'img'):
            child = fmts_el.find(key)
            fmts[key] = _to_bool(child.text if child is not None else None)
    profile['formats'] = fmts

    def get_text(tag, default=''):
        el = root.find(tag)
        return el.text if el is not None and el.text is not None else default

    profile['enable_3d'] = _to_bool(get_text('EnableEnable3D'))
    profile['paper_size'] = get_text('PaperSize', 'Sheet Size (as titleblock)')
    profile['orientation'] = get_text('Orientation', 'Auto')
    profile['placement_center'] = _to_bool(get_text('PlacementCenter'), True)
    profile['offset_x_mm'] = get_text('OffsetX', '0.00')
    profile['offset_y_mm'] = get_text('OffsetY', '0.00')
    profile['zoom_fit'] = _to_bool(get_text('ZoomFit'), True)
    profile['zoom_pct'] = get_text('ZoomPct', '100')
    profile['vector_processing'] = _to_bool(get_text('VectorProcessing'), True)
    profile['raster_quality'] = get_text('RasterQuality', 'High')
    profile['colors'] = get_text('Colors', 'Color')
    profile['view_links_blue'] = _to_bool(get_text('ViewLinksBlue'))
    profile['hide_ref_planes'] = _to_bool(get_text('HideRefPlanes'))
    profile['hide_unref_tags'] = _to_bool(get_text('HideUnrefTags'), True)
    profile['hide_scope_boxes'] = _to_bool(get_text('HideScopeBoxes'), True)
    profile['hide_crop_boundaries'] = _to_bool(get_text('HideCropBoundaries'), True)
    profile['dwg_setup_name'] = get_text('DwgSetupName', DEFAULT_DWG_LABEL)
    profile['dwg_xrefs'] = _to_bool(get_text('DwgXrefs'))
    profile['dwg_clean_pcp'] = _to_bool(get_text('DwgCleanPcp'))
    profile['separate_files'] = _to_bool(get_text('SeparateFiles'), True)
    profile['output_folder'] = get_text('OutputFolder', '')
    profile['view3d_name'] = get_text('View3DName', '')
    profile['naming_sep_enabled'] = _to_bool(get_text('NamingSepEnabled'), True)
    profile['naming_sep_char'] = get_text('NamingSepChar', '-')

    profile['dwf_is_dwfx'] = _to_bool(get_text('DwfIsDwfx'))
    profile['dwf_cropbox'] = _to_bool(get_text('DwfCropbox'))
    profile['dwf_export_object_data'] = _to_bool(get_text('DwfExportObjectData'))
    profile['dwf_export_areas'] = _to_bool(get_text('DwfExportAreas'))
    profile['dwf_export_textures'] = _to_bool(get_text('DwfExportTextures'))
    profile['dwf_xrefs'] = _to_bool(get_text('DwfXrefs'))
    profile['dwf_image_quality'] = get_text('DwfImageQuality', 'High')

    profile['nwc_coordinates'] = get_text('NwcCoordinates', 'Shared')
    profile['nwc_divide_levels'] = _to_bool(get_text('NwcDivideLevels'), True)
    profile['nwc_export_links'] = _to_bool(get_text('NwcExportLinks'))
    profile['nwc_export_room_geometry'] = _to_bool(get_text('NwcExportRoomGeometry'), True)
    profile['nwc_faceting_factor'] = get_text('NwcFacetingFactor', '1')

    profile['img_fit_to_pixels'] = _to_bool(get_text('ImgFitToPixels'), True)
    profile['img_pixels'] = get_text('ImgPixels', '2048')
    profile['img_direction'] = get_text('ImgDirection', 'Horizontal')
    profile['img_zoom_pct'] = get_text('ImgZoomPct', '50')
    profile['img_shaded_format'] = get_text('ImgShadedFormat', 'PNG')
    profile['img_nonshaded_format'] = get_text('ImgNonShadedFormat', 'PNG')
    profile['img_dpi'] = get_text('ImgDpi', 'DPI_72')

    profile['sheet_number_filter'] = get_text('SheetNumberFilter', '')
    profile['dated_subfolder'] = _to_bool(get_text('DatedSubfolder'), True)

    entries = []
    entries_el = root.find('NamingEntries')
    if entries_el is not None:
        for entry_el in entries_el.findall('Entry'):
            entries.append({'type': entry_el.get('type'), 'value': entry_el.get('value')})
    profile['naming_entries'] = entries if entries else [dict(e) for e in DEFAULT_NAMING_ENTRIES]

    return profile


# ---------------------------------------------------------------------------
# Per-format export functions
# All take an explicit `document` + `log` (a pyrevit logger, or anything
# with .warn()/.error()) so they never depend on any module-level global -
# safe to call from a WPF window OR a headless script.
# ---------------------------------------------------------------------------

def configure_common_paper(opt, settings, log=None):
    """Apply paper size / orientation / placement / zoom - only valid on
    PDFExportOptions. Each assignment is wrapped individually so a
    version-specific renamed enum member skips just that one setting
    instead of failing the whole sheet's export."""

    def _set(attr, value, label):
        try_set_attr(opt, attr, value, label, log)

    label = settings['paper_size']
    if label in PAPER_FORMAT_MAP:
        _set('PaperFormat', getattr(ExportPaperFormat, PAPER_FORMAT_MAP[label]), 'Paper Format')
    else:
        _set('PaperFormat', ExportPaperFormat.Default, 'Paper Format (Default)')

    orientation_map = {
        'Auto': PageOrientationType.Auto,
        'Portrait': PageOrientationType.Portrait,
        'Landscape': PageOrientationType.Landscape,
    }
    _set('PaperOrientation', orientation_map[settings['orientation']], 'Paper Orientation')

    if settings['placement_center']:
        _set('PaperPlacement', PaperPlacementType.Center, 'Paper Placement (Center)')
    else:
        # NOTE: the "offset from corner" placement is PaperPlacementType.LowerLeft
        # in the real Revit API - NOT "OffsetFromCorner" (confirmed).
        _set('PaperPlacement', PaperPlacementType.LowerLeft, 'Paper Placement (Offset)')
        _set('MarginType', MarginType.UserDefined, 'Margin Type')
        _set('UserDefinedMarginX', mm_to_inch(settings['offset_x_mm']), 'Margin X')
        _set('UserDefinedMarginY', mm_to_inch(settings['offset_y_mm']), 'Margin Y')

    if settings['zoom_fit']:
        try_set_enum_attr(opt, 'ZoomType', 'FitToPage', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Fit to Page)', log)
    else:
        try_set_enum_attr(opt, 'ZoomType', 'Zoom', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Zoom %)', log)
        try:
            pct = int(float(settings['zoom_pct']))
        except ValueError:
            pct = 100
        _set('ZoomPercentage', pct, 'Zoom Percentage')


def get_dwg_options(dwg_setups, settings, log=None):
    """Start from a saved DWG Export Setup if one is selected, otherwise
    Revit's default DWGExportOptions - then apply the xref checkbox."""
    setup_name = settings.get('dwg_setup_name', DEFAULT_DWG_LABEL)
    opt = None
    if setup_name and setup_name != DEFAULT_DWG_LABEL:
        setup_el = dwg_setups.get(setup_name)
        if setup_el is not None:
            try:
                opt = setup_el.GetDWGExportOptions()
            except Exception as ex:
                if log:
                    log.warn('Could not read DWG export setup "{0}": {1}'.format(setup_name, ex))
    if opt is None:
        opt = DWGExportOptions()

    try_set_attr(opt, 'MergedViews', not settings.get('dwg_xrefs', False), 'Merged Views (xrefs)', log)
    return opt


def export_pdf(document, sheet, settings, results, log=None):
    name = build_filename_from_tokens(document, settings['naming_tokens'], sheet)
    try:
        opt = PDFExportOptions()
        opt.FileName = name
        opt.Combine = True  # one call = one named file, for full naming control
        configure_common_paper(opt, settings, log)

        opt.RasterQuality = {
            'Low': RasterQualityType.Low,
            'Medium': RasterQualityType.Medium,
            'High': RasterQualityType.High,
            'Presentation': RasterQualityType.Presentation,
        }.get(settings['raster_quality'], RasterQualityType.High)

        opt.ColorDepth = {
            'Color': ColorDepthType.Color,
            'Black Line': ColorDepthType.BlackLine,
            'Grayscale': ColorDepthType.GrayScale,
        }.get(settings['colors'], ColorDepthType.Color)

        opt.HideCropBoundaries = settings['hide_crop_boundaries']
        opt.HideScopeBoxes = settings['hide_scope_boxes']
        opt.HideUnreferencedViewTags = settings['hide_unref_tags']
        opt.HideReferencePlane = settings['hide_ref_planes']
        opt.ViewLinksInBlue = settings['view_links_blue']
        opt.AlwaysUseRaster = settings['vector_processing'] is False

        view_ids = System.Collections.Generic.List[ElementId]([sheet.Id])
        document.Export(settings['output_folder'], view_ids, opt)
        results.append((True, name + '.pdf', None))
    except Exception as ex:
        if log:
            log.error('PDF export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
        results.append((False, sheet.SheetNumber + ' (PDF)', str(ex)))


def export_dwg(document, sheet, settings, results, dwg_setups, log=None):
    name = build_filename_from_tokens(document, settings['naming_tokens'], sheet)
    try:
        opt = get_dwg_options(dwg_setups, settings, log)
        view_ids = System.Collections.Generic.List[ElementId]([sheet.Id])
        document.Export(settings['output_folder'], name, view_ids, opt)
        if settings.get('dwg_clean_pcp'):
            clean_pcp_file(settings['output_folder'], name, log)
        results.append((True, name + '.dwg', None))
    except Exception as ex:
        if log:
            log.error('DWG export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
        results.append((False, sheet.SheetNumber + ' (DWG)', str(ex)))


def export_dwf(document, sheet, settings, results, log=None):
    if not HAS_DWF:
        results.append((False, sheet.SheetNumber + ' (DWF)',
                         'DWFExportOptions not available in this Revit API version.'))
        return
    name = build_filename_from_tokens(document, settings['naming_tokens'], sheet)
    try:
        # DWFExportOptions is NOT related to PDFExportOptions/DWGExportOptions
        # in the real Revit API (confirmed against Autodesk's class hierarchy
        # docs) - only the properties below are real for DWF/DWFx.
        if settings.get('dwf_is_dwfx') and HAS_DWFX:
            opt = DWFXExportOptions()
        else:
            opt = DWFExportOptions()

        try_set_attr(opt, 'CropBoxVisible', settings['dwf_cropbox'], 'Cropbox Visible', log)
        try_set_attr(opt, 'ExportObjectData', settings['dwf_export_object_data'], 'Export Element Properties', log)
        try_set_attr(opt, 'ExportingAreas', settings['dwf_export_areas'], 'Export Rooms/Spaces/Areas', log)
        try_set_attr(opt, 'ExportTexture', settings['dwf_export_textures'], 'Export Textures', log)
        try_set_attr(opt, 'MergedViews', not settings.get('dwf_xrefs', False), 'Merged Views (xrefs)', log)
        quality_map = {'Low': 1, 'Medium': 2, 'High': 3, 'Default': 0}
        try_set_attr(opt, 'ImageQuality', quality_map.get(settings.get('dwf_image_quality'), 0),
                     'Image Quality', log)

        view_ids = System.Collections.Generic.List[ElementId]([sheet.Id])
        document.Export(settings['output_folder'], name, view_ids, opt)
        results.append((True, name + ('.dwfx' if settings.get('dwf_is_dwfx') else '.dwf'), None))
    except Exception as ex:
        if log:
            log.error('DWF export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
        results.append((False, sheet.SheetNumber + ' (DWF)', str(ex)))


def export_image(document, sheet, settings, results, log=None):
    name = build_filename_from_tokens(document, settings['naming_tokens'], sheet)
    try:
        opt = ImageExportOptions()
        opt.ExportRange = ExportRange.SetOfViews
        opt.SetViewsAndSheets(System.Collections.Generic.List[ElementId]([sheet.Id]))
        opt.FilePath = os.path.join(settings['output_folder'], name)

        if settings.get('img_fit_to_pixels', True):
            try_set_enum_attr(opt, 'ZoomType', 'FitToPage', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Fit)', log)
            try:
                pixels = int(float(settings.get('img_pixels', 2048)))
            except (TypeError, ValueError):
                pixels = 2048
            try_set_attr(opt, 'PixelSize', pixels, 'Pixel Size', log)
        else:
            try_set_enum_attr(opt, 'ZoomType', 'Zoom', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Zoom %)', log)
            try:
                zoom_pct = int(float(settings.get('img_zoom_pct', 50)))
            except (TypeError, ValueError):
                zoom_pct = 50
            try_set_attr(opt, 'Zoom', zoom_pct, 'Zoom Percentage', log)

        direction = FitDirectionType.Vertical if settings.get('img_direction') == 'Vertical' else FitDirectionType.Horizontal
        try_set_attr(opt, 'FitDirection', direction, 'Fit Direction', log)

        file_type_map = {
            'PNG': ImageFileType.PNG,
            'JPEG': getattr(ImageFileType, 'JPEGLossless', ImageFileType.PNG),
            'BMP': getattr(ImageFileType, 'BMP', ImageFileType.PNG),
            'TARGA': getattr(ImageFileType, 'TARGA', ImageFileType.PNG),
        }
        try_set_attr(opt, 'HLRandWFViewsFileType',
                     file_type_map.get(settings.get('img_nonshaded_format'), ImageFileType.PNG),
                     'Non-Shaded Views Format', log)
        try_set_attr(opt, 'ShadowViewsFileType',
                     file_type_map.get(settings.get('img_shaded_format'), ImageFileType.PNG),
                     'Shaded Views Format', log)

        dpi_map = {
            'DPI_72': ImageResolution.DPI_72, 'DPI_150': ImageResolution.DPI_150,
            'DPI_300': ImageResolution.DPI_300, 'DPI_600': ImageResolution.DPI_600,
        }
        try_set_attr(opt, 'ImageResolution', dpi_map.get(settings.get('img_dpi'), ImageResolution.DPI_72),
                     'Raster Image Quality', log)

        # NOTE: Revit auto-appends the view name / an index suffix to
        # FilePath when exporting a SetOfViews - exact single-sheet name
        # control isn't guaranteed here.
        document.ExportImage(opt)
        results.append((True, name + ' (image, approx. name)', None))
    except Exception as ex:
        if log:
            log.error('Image export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
        results.append((False, sheet.SheetNumber + ' (IMG)', str(ex)))


def export_ifc(document, settings, results, log=None):
    if not HAS_IFC:
        results.append((False, 'IFC', 'IFC export module not loaded/available.'))
        return
    name = sanitize_filename(get_project_number(document) or document.Title)
    try:
        opt = IFCExportOptions()
        document.Export(settings['output_folder'], name, opt)
        results.append((True, name + '.ifc', None))
    except Exception as ex:
        if log:
            log.error('IFC export failed: {0}'.format(ex))
        results.append((False, 'IFC', str(ex)))


def export_nwc(document, settings, results, view3d_list, log=None):
    if not HAS_NWC:
        results.append((False, 'NWC',
                         'NavisworksExportOptions not found - install the '
                         '"Navisworks Exporter for Revit" add-in separately.'))
        return
    if not settings['view3d_name']:
        results.append((False, 'NWC', 'No 3D view available to export.'))
        return
    name = sanitize_filename(get_project_number(document) or document.Title)
    try:
        view3d = next((v for v in view3d_list if v.Name == settings['view3d_name']), None)
        if view3d is None:
            results.append((False, 'NWC', 'Selected 3D view not found.'))
            return
        opt = NavisworksExportOptions()

        try_set_attr(opt, 'ExportScope', NavisworksExportScope.View, 'Export Scope (View)', log)
        try_set_attr(opt, 'ViewId', view3d.Id, 'View Id', log)

        coord_map = {'Shared': 'Shared', 'Internal': 'Internal'}
        coord_name = coord_map.get(settings.get('nwc_coordinates'), 'Shared')
        coord_value = getattr(NavisworksCoordinates, coord_name, getattr(NavisworksCoordinates, 'Shared', None))
        if coord_value is not None:
            try_set_attr(opt, 'Coordinates', coord_value, 'Coordinates', log)

        try_set_attr(opt, 'DivideFileIntoLevels', settings.get('nwc_divide_levels', True), 'Divide File Into Levels', log)
        try_set_attr(opt, 'ExportLinks', settings.get('nwc_export_links', False), 'Convert Linked Files', log)
        try_set_attr(opt, 'ExportRoomGeometry', settings.get('nwc_export_room_geometry', True), 'Export Room Geometry', log)

        try:
            facet = float(settings.get('nwc_faceting_factor', 1))
        except (TypeError, ValueError):
            facet = 1.0
        try_set_attr(opt, 'FacetingFactor', facet, 'Faceting Factor', log)

        document.Export(settings['output_folder'], name, opt)
        results.append((True, name + '.nwc', None))
    except Exception as ex:
        if log:
            log.error('NWC export failed: {0}'.format(ex))
        results.append((False, 'NWC', str(ex)))


# ---------------------------------------------------------------------------
# Shared batch orchestrator - loops every selected format/sheet. Used by
# both the interactive window (with a progress callback) and the headless
# script (no callback, just logs at the end).
# ---------------------------------------------------------------------------

def validate_export_request(settings, selected_sheets):
    """Returns None if OK to proceed, or an error message string."""
    if not any(settings['formats'].values()):
        return 'No export format selected.'
    if not settings['output_folder']:
        return 'No output folder set.'
    needs_sheets = settings['formats']['pdf'] or settings['formats']['dwg'] \
        or settings['formats']['dwf'] or settings['formats']['img']
    if needs_sheets and not selected_sheets:
        return 'No sheets selected/matched for PDF/DWG/DWF/IMG export.'
    return None


def run_export_batch(document, selected_sheets, settings, dwg_setups, view3d_list,
                      log=None, on_progress=None):
    """Runs the full export batch. Returns the results list:
    [(success_bool, label, error_or_None), ...]

    on_progress(status_text, fraction_0_to_1), if given, is called between
    steps - the GUI uses this to update its progress bar; the headless
    script simply omits it."""
    error = validate_export_request(settings, selected_sheets)
    if error:
        return [(False, 'Bulk Export', error)]

    if not os.path.isdir(settings['output_folder']):
        try:
            os.makedirs(settings['output_folder'])
        except Exception as ex:
            return [(False, 'Output folder', 'Could not create output folder: {0}'.format(ex))]

    results = []
    formats = settings['formats']
    needs_sheets = formats['pdf'] or formats['dwg'] or formats['dwf'] or formats['img']

    total_steps = 0
    if needs_sheets:
        total_steps += len(selected_sheets) * sum(
            1 for k in ('pdf', 'dwg', 'dwf', 'img') if formats[k])
    if formats['ifc']:
        total_steps += 1
    if formats['nwc']:
        total_steps += 1
    total_steps = max(total_steps, 1)
    done = [0]

    def tick(status):
        done[0] += 1
        if on_progress:
            on_progress(status, done[0] / float(total_steps))

    if formats['pdf']:
        for sh in selected_sheets:
            export_pdf(document, sh, settings, results, log)
            tick('PDF: {0}'.format(sh.SheetNumber))

    if formats['dwg']:
        for sh in selected_sheets:
            export_dwg(document, sh, settings, results, dwg_setups, log)
            tick('DWG: {0}'.format(sh.SheetNumber))

    if formats['dwf']:
        for sh in selected_sheets:
            export_dwf(document, sh, settings, results, log)
            tick('DWF: {0}'.format(sh.SheetNumber))

    if formats['img']:
        for sh in selected_sheets:
            export_image(document, sh, settings, results, log)
            tick('IMG: {0}'.format(sh.SheetNumber))

    if formats['ifc']:
        export_ifc(document, settings, results, log)
        tick('IFC: whole model')

    if formats['nwc']:
        if settings.get('enable_3d'):
            export_nwc(document, settings, results, view3d_list, log)
        else:
            results.append((False, 'NWC', 'Skipped - "Enable 3D view export" switch is OFF.'))
        tick('NWC: whole model')

    return results
