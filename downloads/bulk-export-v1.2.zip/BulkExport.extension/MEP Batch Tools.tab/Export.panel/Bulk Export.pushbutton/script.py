# -*- coding: utf-8 -*-
"""
Bulk Export - MEP Batch Tools
------------------------------
Batch-export selected sheets to PDF / DWG / DWF / IFC / Images (and NWC for a
3D view) in a single pass, with configurable paper size, orientation, paper
placement, zoom, "hide" options, a real DWG Export Setup picker, a
parameter-picker file naming builder, and shareable XML profiles.

Built for pyRevit. Tested against the general Revit API surface used from
~2021 through 2025; a few properties/enum names shift slightly between
Revit versions, so anywhere marked "VERIFY" below is worth a quick check
against the Revit API help file for your installed version before running
this on a live production folder.

Developed by: Sri Ram
Contact: sreeram14092002@gmail.com

NOTE for future maintenance: the scheduled/unattended export path
(Scheduled Export.pushbutton + lib/scheduled_export.py) uses its own
copy of the export engine in lib/bulk_export_core.py, kept manually in
sync with the per-format export logic in this file rather than sharing
it directly. If you fix a bug in one of the _export_pdf/_export_dwg/
_export_dwf/_export_image/_export_ifc/_export_nwc methods below, make
the same fix in lib/bulk_export_core.py's equivalent function - they
were in sync as of this writing but nothing enforces that automatically.
"""

import os
import re
import datetime
import xml.etree.ElementTree as ET

import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
clr.AddReference('PresentationFramework')
clr.AddReference('PresentationCore')
clr.AddReference('System.Windows.Forms')
clr.AddReference('WindowsBase')

from Autodesk.Revit.DB import (
    FilteredElementCollector, ViewSheet, View3D, BuiltInParameter,
    ElementId, StorageType
)

# --- PDF ---
from Autodesk.Revit.DB import (
    PDFExportOptions, ExportPaperFormat, PageOrientationType,
    PaperPlacementType, ZoomFitType, RasterQualityType, ColorDepthType,
    MarginType
)
try:
    # Confirmed via a real crash report: some Revit versions (2027 seen
    # so far) want a distinct "ZoomType" enum for this property instead
    # of ZoomFitType, even though both have identical member names
    # (.FitToPage, .Zoom). Try both at runtime rather than guessing which
    # one a given install wants.
    from Autodesk.Revit.DB import ZoomType as _ZoomTypeEnum
    HAS_ZOOMTYPE_ENUM = True
except ImportError:
    HAS_ZOOMTYPE_ENUM = False
    _ZoomTypeEnum = None
# --- DWG / DWF ---
from Autodesk.Revit.DB import DWGExportOptions
try:
    from Autodesk.Revit.DB import ExportDWGSettings
    HAS_DWG_SETUPS = True
except ImportError:
    HAS_DWG_SETUPS = False
try:
    HAS_DWFX = False
    from Autodesk.Revit.DB import DWFExportOptions
    try:
        from Autodesk.Revit.DB import DWFXExportOptions
        HAS_DWFX = True
    except ImportError:
        HAS_DWFX = False
    HAS_DWF = True
except ImportError:
    HAS_DWF = False
# --- IFC ---
try:
    from Autodesk.Revit.DB.IFC import IFCExportOptions
    HAS_IFC = True
except ImportError:
    HAS_IFC = False
# --- Images ---
from Autodesk.Revit.DB import (
    ImageExportOptions, ExportRange, ImageFileType, ImageResolution,
    FitDirectionType
)
# --- NWC (requires the separate "Navisworks Exporter for Revit" add-in) ---
try:
    from Autodesk.Revit.DB import NavisworksExportOptions, NavisworksCoordinates, NavisworksExportScope
    HAS_NWC = True
except ImportError:
    HAS_NWC = False

import System
from System.Collections.ObjectModel import ObservableCollection
try:
    clr.AddReference('System.ObjectModel')
except Exception:
    pass
try:
    from System.ComponentModel import INotifyPropertyChanged, PropertyChangedEventArgs
    HAS_INOTIFY = True
except ImportError:
    # Seen on Revit 2027 - its newer .NET runtime doesn't resolve this
    # interface the same way IronPython/.NET Framework did. Degrade
    # gracefully: sheet checkboxes still work individually, only the
    # "instant visual refresh" after Select All/None needs a manual
    # ItemsSource reset instead (handled in btnSelectAll/None below).
    HAS_INOTIFY = False
    INotifyPropertyChanged = object
    PropertyChangedEventArgs = None
from System.Windows import Visibility
from System.Windows.Forms import FolderBrowserDialog, DialogResult, OpenFileDialog, SaveFileDialog
from System.Windows.Threading import DispatcherPriority

from pyrevit import forms, script, revit

logger = script.get_logger()
output = script.get_output()

doc = revit.doc
uidoc = revit.uidoc

XAML_FILE = os.path.join(os.path.dirname(__file__), 'ui.xaml')
BUILDER_XAML_FILE = os.path.join(os.path.dirname(__file__), 'filename_builder.xaml')

DEFAULT_DWG_LABEL = '<Default Revit Settings>'

PROFILES_DIR = os.path.join(
    os.environ.get('APPDATA', os.path.expanduser('~')),
    'BulkExportTools', 'Profiles')

ABOUT_TEXT = (
    'Bulk Export - MEP Batch Tools\n\n'
    'Developed by: Sri Ram\n'
    'Contact: sreeram14092002@gmail.com\n\n'
    'Batch export Revit sheets to PDF, DWG, DWF, IFC and Images in one pass, '
    'with a parameter-driven file naming builder and shareable XML profiles.'
)


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def mm_to_inch(mm_value):
    """PDFExportOptions margins are expressed in inches (VERIFY on your
    Revit version). The dialog shows margins in mm, so we convert here."""
    try:
        return float(mm_value) / 25.4
    except (TypeError, ValueError):
        return 0.0


def sanitize_filename(name):
    """Strip characters that are illegal in Windows file names."""
    return re.sub(r'[\\/:*?"<>|]', '_', name).strip()


def clean_pcp_file(output_folder, base_name):
    """Revit's DWG exporter sometimes leaves a .pcp (plot config) file
    alongside the .dwg. Deletes it if present. Real, working file cleanup -
    unlike "Bind Images as OLE", this needs no external application."""
    pcp_path = os.path.join(output_folder, base_name + '.pcp')
    if os.path.isfile(pcp_path):
        try:
            os.remove(pcp_path)
            return True
        except Exception as ex:
            logger.warn('Could not delete .pcp file "{0}": {1}'.format(pcp_path, ex))
    return False


def get_project_number(document):
    proj_info = document.ProjectInformation
    try:
        return proj_info.get_Parameter(BuiltInParameter.PROJECT_NUMBER).AsString() or ''
    except Exception:
        return ''


def get_current_revision_number(sheet):
    try:
        rev_id = sheet.GetCurrentRevision()
        if rev_id and rev_id != ElementId.InvalidElementId:
            rev = doc.GetElement(rev_id)
            param = rev.get_Parameter(BuiltInParameter.PROJECT_REVISION_REVISION_NUM)
            if param:
                return param.AsString() or ''
    except Exception:
        pass
    return ''


def ensure_dir(path):
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Parameter discovery + value lookup (drives the "Edit filename" builder)
# ---------------------------------------------------------------------------

def get_all_sheet_parameter_names(document):
    """Union of all parameter display names found across every sheet in the
    project. Slightly slower on huge projects but catches discipline-specific
    shared parameters that only exist on some sheets."""
    names = set(['Sheet Number', 'Sheet Name', 'Current Revision'])
    try:
        for sh in FilteredElementCollector(document).OfClass(ViewSheet).ToElements():
            for p in sh.Parameters:
                try:
                    names.add(p.Definition.Name)
                except Exception:
                    pass
    except Exception:
        pass
    return sorted(names)


def get_project_info_parameter_names(document):
    names = set()
    try:
        for p in document.ProjectInformation.Parameters:
            try:
                names.add(p.Definition.Name)
            except Exception:
                pass
    except Exception:
        pass
    return sorted(names)


# Fallbacks for parameters that aren't reliably read via a plain
# LookupParameter() call on every Revit version.
_SPECIAL_PARAM_GETTERS = {
    'Sheet Number': lambda sheet: sheet.SheetNumber,
    'Sheet Name': lambda sheet: sheet.Name,
    'Current Revision': lambda sheet: get_current_revision_number(sheet),
}


def get_param_value_by_name(sheet, name):
    getter = _SPECIAL_PARAM_GETTERS.get(name)
    if getter:
        try:
            val = getter(sheet)
            if val:
                return val
        except Exception:
            pass

    p = sheet.LookupParameter(name)
    if p is None:
        try:
            p = doc.ProjectInformation.LookupParameter(name)
        except Exception:
            p = None
    if p is None:
        return ''

    try:
        if p.StorageType == StorageType.String:
            return p.AsString() or ''
        elif p.StorageType == StorageType.Integer:
            return str(p.AsInteger())
        elif p.StorageType == StorageType.Double:
            return p.AsValueString() or str(p.AsDouble())
        elif p.StorageType == StorageType.ElementId:
            eid = p.AsElementId()
            if eid and eid != ElementId.InvalidElementId:
                el = doc.GetElement(eid)
                return el.Name if el and hasattr(el, 'Name') else str(eid.IntegerValue)
            return ''
    except Exception:
        pass
    return ''


# ---------------------------------------------------------------------------
# Naming "entries" (what the builder dialog edits) -> "tokens" (baked,
# ready-to-export list with separators already inserted between fields)
# ---------------------------------------------------------------------------

DEFAULT_NAMING_ENTRIES = [
    {'type': 'param', 'value': 'Project Number'},
    {'type': 'param', 'value': 'Sheet Number'},
    {'type': 'param', 'value': 'Sheet Name'},
]
DEFAULT_SEPARATOR_ENABLED = True
DEFAULT_SEPARATOR_CHAR = '-'


def bake_tokens(entries, sep_enabled, sep_char):
    """Insert the field separator between two consecutive PARAMETER entries
    only - literal entries (like manually-added '(' ')' or custom text) sit
    exactly where you put them with no extra separator around them, matching
    the 'Edit filename' dialog behavior."""
    tokens = []
    prev_type = None
    for e in entries:
        if e['type'] == 'param':
            if sep_enabled and prev_type == 'param' and sep_char:
                tokens.append({'type': 'literal', 'value': sep_char})
            tokens.append({'type': 'param', 'key': e['value']})
            prev_type = 'param'
        else:
            tokens.append({'type': 'literal', 'value': e['value']})
            prev_type = 'literal'
    return tokens


def build_filename_from_tokens(tokens, sheet):
    parts = []
    for tok in tokens:
        if tok['type'] == 'param':
            parts.append(get_param_value_by_name(sheet, tok['key']) or '')
        else:
            parts.append(tok['value'])
    return sanitize_filename(''.join(parts))


def try_set_attr(obj, attr_name, value, label=None):
    """Best-effort setattr - a number of export option properties vary or
    don't exist across Revit versions/formats (confirmed the hard way -
    see script header). Logs a warning and continues instead of aborting
    the whole export over one missing/renamed property."""
    try:
        setattr(obj, attr_name, value)
        return True
    except Exception as ex:
        logger.warn('Skipped "{0}" ({1}.{2}): {3}'.format(
            label or attr_name, type(obj).__name__, attr_name, ex))
        return False


def try_set_enum_attr(obj, attr_name, member_name, candidate_enums, label=None):
    """Some Revit properties expect a different (but identically-named-
    member) enum TYPE depending on Revit version - confirmed for the
    .ZoomType property, which wants ZoomFitType on some versions and a
    separate ZoomType enum on others (same .FitToPage/.Zoom members,
    different underlying .NET type). Tries each candidate enum in turn
    and keeps the first one that actually works, instead of guessing one
    and failing silently on versions that want the other."""
    last_ex = None
    for enum_type in candidate_enums:
        if enum_type is None:
            continue
        try:
            value = getattr(enum_type, member_name)
        except Exception as ex:
            last_ex = ex
            continue
        try:
            setattr(obj, attr_name, value)
            return True
        except Exception as ex:
            last_ex = ex
            continue
    logger.warn('Skipped "{0}" ({1}.{2}) - tried {3} enum candidate(s), none worked: {4}'.format(
        label or attr_name, type(obj).__name__, attr_name, len(candidate_enums), last_ex))
    return False


PAPER_FORMAT_MAP = {
    'ISO A0': 'ISO_A0', 'ISO A1': 'ISO_A1', 'ISO A2': 'ISO_A2',
    'ISO A3': 'ISO_A3', 'ISO A4': 'ISO_A4',
    'ANSI A': 'ANSI_A', 'ANSI B': 'ANSI_B', 'ANSI C': 'ANSI_C',
    'ANSI D': 'ANSI_D', 'ANSI E': 'ANSI_E',
    'Arch D': 'ARCH_D', 'Arch E': 'ARCH_E',
}

_ZOOM_ENUM_CANDIDATES = [ZoomFitType, _ZoomTypeEnum] if HAS_ZOOMTYPE_ENUM else [ZoomFitType]


# ---------------------------------------------------------------------------
# DWG export setups (real, saved-in-model setups - Manage tab > Export
# Setups > DWG/DXF)
# ---------------------------------------------------------------------------

def get_dwg_export_setups(document):
    """Returns {display_name: ExportDWGSettings element}."""
    setups = {}
    if not HAS_DWG_SETUPS:
        return setups
    try:
        for el in FilteredElementCollector(document).OfClass(ExportDWGSettings).ToElements():
            try:
                setups[el.Name] = el
            except Exception:
                pass
    except Exception:
        pass
    return setups


# ---------------------------------------------------------------------------
# Profile serialization (shareable XML settings files)
# ---------------------------------------------------------------------------

def _xml_set(parent, tag, value):
    el = ET.SubElement(parent, tag)
    el.text = '' if value is None else str(value)
    return el


def profile_to_xml_string(profile):
    root = ET.Element('BulkExportProfile')
    root.set('version', '1')

    fmts = ET.SubElement(root, 'Formats')
    for key, val in profile['formats'].items():
        _xml_set(fmts, key, 'true' if val else 'false')

    _xml_set(root, 'EnableEnable3D', profile['enable_3d'])
    _xml_set(root, 'PaperSize', profile['paper_size'])
    _xml_set(root, 'Orientation', profile['orientation'])
    _xml_set(root, 'PlacementCenter', profile['placement_center'])
    _xml_set(root, 'OffsetX', profile['offset_x_mm'])
    _xml_set(root, 'OffsetY', profile['offset_y_mm'])
    _xml_set(root, 'ZoomFit', profile['zoom_fit'])
    _xml_set(root, 'ZoomPct', profile['zoom_pct'])
    _xml_set(root, 'VectorProcessing', profile['vector_processing'])
    _xml_set(root, 'RasterQuality', profile['raster_quality'])
    _xml_set(root, 'Colors', profile['colors'])
    _xml_set(root, 'ViewLinksBlue', profile['view_links_blue'])
    _xml_set(root, 'HideRefPlanes', profile['hide_ref_planes'])
    _xml_set(root, 'HideUnrefTags', profile['hide_unref_tags'])
    _xml_set(root, 'HideScopeBoxes', profile['hide_scope_boxes'])
    _xml_set(root, 'HideCropBoundaries', profile['hide_crop_boundaries'])
    _xml_set(root, 'DwgSetupName', profile['dwg_setup_name'])
    _xml_set(root, 'DwgXrefs', profile['dwg_xrefs'])
    _xml_set(root, 'DwgCleanPcp', profile.get('dwg_clean_pcp', False))
    _xml_set(root, 'SeparateFiles', profile['separate_files'])
    _xml_set(root, 'OutputFolder', profile['output_folder'])
    _xml_set(root, 'View3DName', profile['view3d_name'])
    _xml_set(root, 'NamingSepEnabled', profile['naming_sep_enabled'])
    _xml_set(root, 'NamingSepChar', profile['naming_sep_char'])

    _xml_set(root, 'DwfIsDwfx', profile.get('dwf_is_dwfx', False))
    _xml_set(root, 'DwfCropbox', profile.get('dwf_cropbox', False))
    _xml_set(root, 'DwfExportObjectData', profile.get('dwf_export_object_data', False))
    _xml_set(root, 'DwfExportAreas', profile.get('dwf_export_areas', False))
    _xml_set(root, 'DwfExportTextures', profile.get('dwf_export_textures', False))
    _xml_set(root, 'DwfXrefs', profile.get('dwf_xrefs', False))
    _xml_set(root, 'DwfImageQuality', profile.get('dwf_image_quality', 'High'))

    _xml_set(root, 'NwcCoordinates', profile.get('nwc_coordinates', 'Shared'))
    _xml_set(root, 'NwcDivideLevels', profile.get('nwc_divide_levels', True))
    _xml_set(root, 'NwcExportLinks', profile.get('nwc_export_links', False))
    _xml_set(root, 'NwcExportRoomGeometry', profile.get('nwc_export_room_geometry', True))
    _xml_set(root, 'NwcFacetingFactor', profile.get('nwc_faceting_factor', '1'))

    _xml_set(root, 'ImgFitToPixels', profile.get('img_fit_to_pixels', True))
    _xml_set(root, 'ImgPixels', profile.get('img_pixels', '2048'))
    _xml_set(root, 'ImgDirection', profile.get('img_direction', 'Horizontal'))
    _xml_set(root, 'ImgZoomPct', profile.get('img_zoom_pct', '50'))
    _xml_set(root, 'ImgShadedFormat', profile.get('img_shaded_format', 'PNG'))
    _xml_set(root, 'ImgNonShadedFormat', profile.get('img_nonshaded_format', 'PNG'))
    _xml_set(root, 'ImgDpi', profile.get('img_dpi', 'DPI_72'))

    entries_el = ET.SubElement(root, 'NamingEntries')
    for e in profile['naming_entries']:
        entry_el = ET.SubElement(entries_el, 'Entry')
        entry_el.set('type', e['type'])
        entry_el.set('value', e['value'])

    return ET.tostring(root, encoding='utf-8')


def _to_bool(text, default=False):
    if text is None:
        return default
    return text.strip().lower() == 'true'


def xml_string_to_profile(xml_text):
    root = ET.fromstring(xml_text)
    profile = {}

    fmts = {}
    fmts_el = root.find('Formats')
    if fmts_el is not None:
        for key in ('pdf', 'dwg', 'dwf', 'nwc', 'ifc', 'img'):
            child = fmts_el.find(key)
            fmts[key] = _to_bool(child.text if child is not None else None)
    profile['formats'] = fmts

    def get_text(tag, default=''):
        el = root.find(tag)
        return el.text if el is not None and el.text is not None else default

    profile['enable_3d'] = _to_bool(get_text('EnableEnable3D'))
    profile['paper_size'] = get_text('PaperSize', 'Sheet Size (as titleblock)')
    profile['orientation'] = get_text('Orientation', 'Auto')
    profile['placement_center'] = _to_bool(get_text('PlacementCenter'), True)
    profile['offset_x_mm'] = get_text('OffsetX', '0.00')
    profile['offset_y_mm'] = get_text('OffsetY', '0.00')
    profile['zoom_fit'] = _to_bool(get_text('ZoomFit'), True)
    profile['zoom_pct'] = get_text('ZoomPct', '100')
    profile['vector_processing'] = _to_bool(get_text('VectorProcessing'), True)
    profile['raster_quality'] = get_text('RasterQuality', 'High')
    profile['colors'] = get_text('Colors', 'Color')
    profile['view_links_blue'] = _to_bool(get_text('ViewLinksBlue'))
    profile['hide_ref_planes'] = _to_bool(get_text('HideRefPlanes'))
    profile['hide_unref_tags'] = _to_bool(get_text('HideUnrefTags'), True)
    profile['hide_scope_boxes'] = _to_bool(get_text('HideScopeBoxes'), True)
    profile['hide_crop_boundaries'] = _to_bool(get_text('HideCropBoundaries'), True)
    profile['dwg_setup_name'] = get_text('DwgSetupName', DEFAULT_DWG_LABEL)
    profile['dwg_xrefs'] = _to_bool(get_text('DwgXrefs'))
    profile['dwg_clean_pcp'] = _to_bool(get_text('DwgCleanPcp'))
    profile['separate_files'] = _to_bool(get_text('SeparateFiles'), True)
    profile['output_folder'] = get_text('OutputFolder', '')
    profile['view3d_name'] = get_text('View3DName', '')
    profile['naming_sep_enabled'] = _to_bool(get_text('NamingSepEnabled'), True)
    profile['naming_sep_char'] = get_text('NamingSepChar', '-')

    profile['dwf_is_dwfx'] = _to_bool(get_text('DwfIsDwfx'))
    profile['dwf_cropbox'] = _to_bool(get_text('DwfCropbox'))
    profile['dwf_export_object_data'] = _to_bool(get_text('DwfExportObjectData'))
    profile['dwf_export_areas'] = _to_bool(get_text('DwfExportAreas'))
    profile['dwf_export_textures'] = _to_bool(get_text('DwfExportTextures'))
    profile['dwf_xrefs'] = _to_bool(get_text('DwfXrefs'))
    profile['dwf_image_quality'] = get_text('DwfImageQuality', 'High')

    profile['nwc_coordinates'] = get_text('NwcCoordinates', 'Shared')
    profile['nwc_divide_levels'] = _to_bool(get_text('NwcDivideLevels'), True)
    profile['nwc_export_links'] = _to_bool(get_text('NwcExportLinks'))
    profile['nwc_export_room_geometry'] = _to_bool(get_text('NwcExportRoomGeometry'), True)
    profile['nwc_faceting_factor'] = get_text('NwcFacetingFactor', '1')

    profile['img_fit_to_pixels'] = _to_bool(get_text('ImgFitToPixels'), True)
    profile['img_pixels'] = get_text('ImgPixels', '2048')
    profile['img_direction'] = get_text('ImgDirection', 'Horizontal')
    profile['img_zoom_pct'] = get_text('ImgZoomPct', '50')
    profile['img_shaded_format'] = get_text('ImgShadedFormat', 'PNG')
    profile['img_nonshaded_format'] = get_text('ImgNonShadedFormat', 'PNG')
    profile['img_dpi'] = get_text('ImgDpi', 'DPI_72')

    entries = []
    entries_el = root.find('NamingEntries')
    if entries_el is not None:
        for entry_el in entries_el.findall('Entry'):
            entries.append({'type': entry_el.get('type'), 'value': entry_el.get('value')})
    profile['naming_entries'] = entries if entries else [dict(e) for e in DEFAULT_NAMING_ENTRIES]

    return profile


# ---------------------------------------------------------------------------
# Bindable list-item for the sheet checklist
# ---------------------------------------------------------------------------

class SheetItem(INotifyPropertyChanged):
    PropertyChanged = None

    def __init__(self, sheet):
        self.Sheet = sheet
        self.Display = '{0} - {1}'.format(sheet.SheetNumber, sheet.Name)
        self._checked = False
        self._handlers = []

    def add_PropertyChanged(self, handler):
        self._handlers.append(handler)

    def remove_PropertyChanged(self, handler):
        self._handlers.remove(handler)

    @property
    def IsChecked(self):
        return self._checked

    @IsChecked.setter
    def IsChecked(self, value):
        self._checked = value
        if HAS_INOTIFY:
            for h in self._handlers:
                h(self, PropertyChangedEventArgs('IsChecked'))
        # If HAS_INOTIFY is False, the value is still stored correctly and
        # a single checkbox click still updates it fine (WPF calls this
        # setter directly) - only a bulk programmatic change (Select
        # All/None) needs the manual refresh done in those handlers below,
        # since there's no notification to tell the UI to re-read this.


# ---------------------------------------------------------------------------
# "Edit filename" builder dialog
# ---------------------------------------------------------------------------

class FilenameBuilderWindow(forms.WPFWindow):

    def __init__(self, xaml_file, entries, sep_enabled, sep_char):
        forms.WPFWindow.__init__(self, xaml_file)

        self.entries = [dict(e) for e in entries]
        self.ok_clicked = False
        self.result_entries = None
        self.result_sep_enabled = sep_enabled
        self.result_sep_char = sep_char

        self.sheet_param_names = get_all_sheet_parameter_names(doc)

        self.chkFieldSeparator.IsChecked = sep_enabled
        self.txtFieldSeparator.Text = sep_char

        self.sample_sheet = None
        sheets = list(FilteredElementCollector(doc).OfClass(ViewSheet).ToElements())
        if sheets:
            sheets.sort(key=lambda s: s.SheetNumber)
            self.sample_sheet = sheets[0]

        self.refresh_available_list()
        self.refresh_selected_list()

    # ----- list refreshers ----------------------------------------------

    def refresh_available_list(self):
        names = list(self.sheet_param_names)
        if self.chkIncludeProjectInfo.IsChecked:
            names = sorted(set(names) | set(get_project_info_parameter_names(doc)))
        query = self.txtParamSearch.Text.strip().lower() if hasattr(self, 'txtParamSearch') else ''
        if query:
            names = [n for n in names if query in n.lower()]
        self.lstAvailable.ItemsSource = names

    def refresh_selected_list(self):
        display_items = []
        for e in self.entries:
            if e['type'] == 'param':
                display_items.append(e['value'])
            else:
                display_items.append('"{0}"'.format(e['value']))
        self.lstSelected.ItemsSource = display_items
        self.update_builder_preview()

    def update_builder_preview(self):
        sep_enabled = self.chkFieldSeparator.IsChecked
        sep_char = self.txtFieldSeparator.Text
        if self.sample_sheet is None:
            self.txtBuilderPreview.Text = 'Preview: (no sheets in project)'
            return
        try:
            tokens = bake_tokens(self.entries, sep_enabled, sep_char)
            name = build_filename_from_tokens(tokens, self.sample_sheet)
            self.txtBuilderPreview.Text = 'Preview: {0}'.format(name)
        except Exception as ex:
            self.txtBuilderPreview.Text = 'Preview error: {0}'.format(ex)

    # ----- event handlers -------------------------------------------------

    def chkIncludeProjectInfo_Changed(self, sender, args):
        self.refresh_available_list()

    def txtParamSearch_TextChanged(self, sender, args):
        self.refresh_available_list()

    def btnAdd_Click(self, sender, args):
        selected = list(self.lstAvailable.SelectedItems)
        for name in selected:
            self.entries.append({'type': 'param', 'value': str(name)})
        self.refresh_selected_list()

    def btnRemove_Click(self, sender, args):
        idx = self.lstSelected.SelectedIndex
        if idx is not None and idx >= 0 and idx < len(self.entries):
            del self.entries[idx]
            self.refresh_selected_list()

    def btnAddCustomField_Click(self, sender, args):
        text = self.txtCustomField.Text.strip()
        if text:
            self.entries.append({'type': 'literal', 'value': text})
            self.txtCustomField.Text = ''
            self.refresh_selected_list()

    def btnAddCustomSeparator_Click(self, sender, args):
        text = self.txtCustomSeparator.Text
        if text:
            self.entries.append({'type': 'literal', 'value': text})
            self.refresh_selected_list()

    def _move_selected(self, new_index):
        idx = self.lstSelected.SelectedIndex
        if idx is None or idx < 0 or idx >= len(self.entries):
            return
        new_index = max(0, min(new_index, len(self.entries) - 1))
        if new_index == idx:
            return
        item = self.entries.pop(idx)
        self.entries.insert(new_index, item)
        self.refresh_selected_list()
        self.lstSelected.SelectedIndex = new_index

    def btnMoveTop_Click(self, sender, args):
        self._move_selected(0)

    def btnMoveUp_Click(self, sender, args):
        idx = self.lstSelected.SelectedIndex
        if idx is not None and idx > 0:
            self._move_selected(idx - 1)

    def btnMoveDown_Click(self, sender, args):
        idx = self.lstSelected.SelectedIndex
        if idx is not None and idx >= 0:
            self._move_selected(idx + 1)

    def btnMoveBottom_Click(self, sender, args):
        self._move_selected(len(self.entries) - 1)

    def btnResetOrder_Click(self, sender, args):
        if forms.alert('Clear all selected parameters?', yes=True, no=True):
            self.entries = []
            self.refresh_selected_list()

    def btnOk_Click(self, sender, args):
        self.result_entries = self.entries
        self.result_sep_enabled = self.chkFieldSeparator.IsChecked
        self.result_sep_char = self.txtFieldSeparator.Text
        self.ok_clicked = True
        self.Close()

    def btnCancel_Click(self, sender, args):
        self.ok_clicked = False
        self.Close()


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------

class BulkExportWindow(forms.WPFWindow):

    def __init__(self, xaml_file):
        forms.WPFWindow.__init__(self, xaml_file)

        ensure_dir(PROFILES_DIR)

        self.all_sheets = list(FilteredElementCollector(doc)
                                .OfClass(ViewSheet)
                                .ToElements())
        self.all_sheets.sort(key=lambda s: s.SheetNumber)

        self.sheet_items = ObservableCollection[object]()
        for sh in self.all_sheets:
            self.sheet_items.Add(SheetItem(sh))
        self.lstSheets.ItemsSource = self.sheet_items

        # 3D views for NWC / whole-model context
        self.view3d_list = list(FilteredElementCollector(doc)
                                 .OfClass(View3D)
                                 .ToElements())
        self.view3d_list = [v for v in self.view3d_list if not v.IsTemplate]
        self.cmb3DView.ItemsSource = [v.Name for v in self.view3d_list]
        if self.view3d_list:
            self.cmb3DView.SelectedIndex = 0

        # DWG export setups saved in this model
        self.dwg_setups = get_dwg_export_setups(doc)
        dwg_names = [DEFAULT_DWG_LABEL] + sorted(self.dwg_setups.keys())
        self.cmbDwgSetup.ItemsSource = dwg_names
        self.cmbDwgSetup.SelectedIndex = 0

        self.txtOutputFolder.Text = ''
        self.results = []

        # Filename builder state
        self.naming_entries = [dict(e) for e in DEFAULT_NAMING_ENTRIES]
        self.naming_sep_enabled = DEFAULT_SEPARATOR_ENABLED
        self.naming_sep_char = DEFAULT_SEPARATOR_CHAR
        self.naming_tokens = bake_tokens(self.naming_entries, self.naming_sep_enabled,
                                          self.naming_sep_char)
        self.update_filename_preview()

        # live filename + status-bar preview
        self.lstSheets.SelectionChanged += self.on_selection_changed_preview

        # Profiles
        self._loading_profile = False
        self.refresh_profile_list()

    # ----- filename / status preview ----------------------------------------

    def update_filename_preview(self):
        display = []
        for e in self.naming_entries:
            display.append(e['value'] if e['type'] == 'param' else '"{0}"'.format(e['value']))
        sep = ' {0} '.format(self.naming_sep_char) if self.naming_sep_enabled else ' '
        self.txtFilenamePreview.Text = sep.join(display) if display else '(not set - click Edit filename)'
        self.on_selection_changed_preview(None, None)

    def on_selection_changed_preview(self, sender, args):
        checked_items = [i for i in self.sheet_items if i.IsChecked]
        self.txtStatusBar.Text = '{0} of {1} sheets selected'.format(
            len(checked_items), len(self.sheet_items))

        sample = checked_items[0] if checked_items else (self.sheet_items[0] if len(self.sheet_items) else None)
        if sample is None:
            self.txtPreview.Text = 'Preview: (no sheets in project)'
            return
        try:
            fname = build_filename_from_tokens(self.naming_tokens, sample.Sheet)
            self.txtPreview.Text = 'Preview: {0}.pdf'.format(fname)
        except Exception as ex:
            self.txtPreview.Text = 'Preview error: {0}'.format(ex)

    # ----- Selection tab handlers -----------------------------------------

    def _force_sheet_list_refresh(self):
        """Only needed when HAS_INOTIFY is False (e.g. Revit 2027 seen so
        far) - forces WPF to fully re-read every checkbox's bound value
        instead of relying on change notifications that aren't available."""
        if not HAS_INOTIFY:
            current = self.lstSheets.ItemsSource
            self.lstSheets.ItemsSource = None
            self.lstSheets.ItemsSource = current

    def btnSelectAll_Click(self, sender, args):
        for item in self.sheet_items:
            item.IsChecked = True
        self._force_sheet_list_refresh()
        self.on_selection_changed_preview(sender, args)

    def btnSelectNone_Click(self, sender, args):
        for item in self.sheet_items:
            item.IsChecked = False
        self._force_sheet_list_refresh()
        self.on_selection_changed_preview(sender, args)

    def txtSheetFilter_TextChanged(self, sender, args):
        query = self.txtSheetFilter.Text.strip().lower()
        if not query:
            self.lstSheets.ItemsSource = self.sheet_items
            return
        filtered = ObservableCollection[object]()
        for item in self.sheet_items:
            if query in item.Display.lower():
                filtered.Add(item)
        self.lstSheets.ItemsSource = filtered

    # ----- Format tab: show/hide per-format settings panels ----------------

    def chkPdf_Changed(self, sender, args):
        self.pnlPdfSettings.Visibility = Visibility.Visible if self.chkPdf.IsChecked else Visibility.Collapsed

    def chkDwg_Changed(self, sender, args):
        self.pnlDwgSettings.Visibility = Visibility.Visible if self.chkDwg.IsChecked else Visibility.Collapsed

    def chkDwf_Changed(self, sender, args):
        self.pnlDwfSettings.Visibility = Visibility.Visible if self.chkDwf.IsChecked else Visibility.Collapsed

    def chkImg_Changed(self, sender, args):
        self.pnlImgSettings.Visibility = Visibility.Visible if self.chkImg.IsChecked else Visibility.Collapsed

    def _model_panel_needed(self):
        return self.chkNwc.IsChecked or self.chkIfc.IsChecked

    def chkNwc_Changed(self, sender, args):
        self.pnlModelSettings.Visibility = Visibility.Visible if self._model_panel_needed() else Visibility.Collapsed

    def chkIfc_Changed(self, sender, args):
        self.pnlModelSettings.Visibility = Visibility.Visible if self._model_panel_needed() else Visibility.Collapsed

    def chkEnable3D_Changed(self, sender, args):
        enabled = self.chkEnable3D.IsChecked
        self.cmb3DView.IsEnabled = enabled
        self.chkNwc.IsEnabled = enabled
        if not enabled:
            self.chkNwc.IsChecked = False

    # ----- Create tab handlers ----------------------------------------------

    def btnBrowse_Click(self, sender, args):
        dlg = FolderBrowserDialog()
        dlg.Description = 'Select output folder for exported files'
        if dlg.ShowDialog() == DialogResult.OK:
            self.txtOutputFolder.Text = dlg.SelectedPath

    def btnEditFilename_Click(self, sender, args):
        dlg = FilenameBuilderWindow(BUILDER_XAML_FILE, self.naming_entries,
                                     self.naming_sep_enabled, self.naming_sep_char)
        try:
            dlg.Owner = self
        except Exception:
            pass
        dlg.ShowDialog()
        if dlg.ok_clicked:
            self.naming_entries = dlg.result_entries
            self.naming_sep_enabled = dlg.result_sep_enabled
            self.naming_sep_char = dlg.result_sep_char
            self.naming_tokens = bake_tokens(self.naming_entries, self.naming_sep_enabled,
                                              self.naming_sep_char)
            self.update_filename_preview()

    def btnAbout_Click(self, sender, args):
        forms.alert(ABOUT_TEXT, title='About')

    def btnClose_Click(self, sender, args):
        self.Close()

    def btnExport_Click(self, sender, args):
        self.run_export()

    # ----- Profile bar -------------------------------------------------------

    def _profile_path(self, name):
        return os.path.join(PROFILES_DIR, sanitize_filename(name) + '.xml')

    def refresh_profile_list(self, select_name=None):
        ensure_dir(PROFILES_DIR)
        names = []
        try:
            for fname in os.listdir(PROFILES_DIR):
                if fname.lower().endswith('.xml'):
                    names.append(fname[:-4])
        except Exception:
            pass
        names.sort()
        self._loading_profile = True
        try:
            self.cmbProfile.ItemsSource = names
            if select_name and select_name in names:
                self.cmbProfile.SelectedItem = select_name
            elif names:
                self.cmbProfile.SelectedIndex = -1
        finally:
            self._loading_profile = False

    def collect_profile(self):
        s = self.get_settings()
        s['dwg_setup_name'] = self.cmbDwgSetup.SelectedItem or DEFAULT_DWG_LABEL
        s['dwg_xrefs'] = self.chkDwgXrefs.IsChecked
        s['naming_entries'] = self.naming_entries
        s['naming_sep_enabled'] = self.naming_sep_enabled
        s['naming_sep_char'] = self.naming_sep_char
        return s

    def apply_profile(self, profile):
        self._loading_profile = True
        try:
            f = profile['formats']
            self.chkPdf.IsChecked = f.get('pdf', True)
            self.chkDwg.IsChecked = f.get('dwg', True)
            self.chkDwf.IsChecked = f.get('dwf', False)
            self.chkIfc.IsChecked = f.get('ifc', False)
            self.chkImg.IsChecked = f.get('img', False)

            self.chkEnable3D.IsChecked = profile.get('enable_3d', False)
            self.chkNwc.IsEnabled = self.chkEnable3D.IsChecked
            self.chkNwc.IsChecked = f.get('nwc', False) and self.chkEnable3D.IsChecked
            self.cmb3DView.IsEnabled = self.chkEnable3D.IsChecked

            self._set_combo_by_content(self.cmbPaperSize, profile.get('paper_size'))
            orient = profile.get('orientation', 'Auto')
            self.radOrientAuto.IsChecked = (orient == 'Auto')
            self.radOrientPortrait.IsChecked = (orient == 'Portrait')
            self.radOrientLandscape.IsChecked = (orient == 'Landscape')

            self.radPlaceCenter.IsChecked = profile.get('placement_center', True)
            self.radPlaceOffset.IsChecked = not profile.get('placement_center', True)
            self.txtOffsetX.Text = str(profile.get('offset_x_mm', '0.00'))
            self.txtOffsetY.Text = str(profile.get('offset_y_mm', '0.00'))

            self.radZoomFit.IsChecked = profile.get('zoom_fit', True)
            self.radZoomPct.IsChecked = not profile.get('zoom_fit', True)
            self.txtZoomPct.Text = str(profile.get('zoom_pct', '100'))

            self.radVector.IsChecked = profile.get('vector_processing', True)
            self.radRaster.IsChecked = not profile.get('vector_processing', True)

            self._set_combo_by_content(self.cmbRasterQuality, profile.get('raster_quality'))
            self._set_combo_by_content(self.cmbColors, profile.get('colors'))

            self.chkViewLinksBlue.IsChecked = profile.get('view_links_blue', False)
            self.chkHideRefPlanes.IsChecked = profile.get('hide_ref_planes', False)
            self.chkHideUnrefTags.IsChecked = profile.get('hide_unref_tags', True)
            self.chkHideScopeBoxes.IsChecked = profile.get('hide_scope_boxes', True)
            self.chkHideCropBoundaries.IsChecked = profile.get('hide_crop_boundaries', True)

            dwg_name = profile.get('dwg_setup_name', DEFAULT_DWG_LABEL)
            if dwg_name in list(self.cmbDwgSetup.ItemsSource or []):
                self.cmbDwgSetup.SelectedItem = dwg_name
            else:
                self.cmbDwgSetup.SelectedIndex = 0
            self.chkDwgXrefs.IsChecked = profile.get('dwg_xrefs', False)
            self.chkDwgCleanPcp.IsChecked = profile.get('dwg_clean_pcp', False)

            self.radDwfFormat.IsChecked = not profile.get('dwf_is_dwfx', False)
            self.radDwfxFormat.IsChecked = profile.get('dwf_is_dwfx', False)
            self.chkDwfCropbox.IsChecked = profile.get('dwf_cropbox', False)
            self.chkDwfExportObjectData.IsChecked = profile.get('dwf_export_object_data', False)
            self.chkDwfExportAreas.IsChecked = profile.get('dwf_export_areas', False)
            self.chkDwfExportTextures.IsChecked = profile.get('dwf_export_textures', False)
            self.chkDwfXrefs.IsChecked = profile.get('dwf_xrefs', False)
            self._set_combo_by_content(self.cmbDwfImageQuality, profile.get('dwf_image_quality'))

            self._set_combo_by_content(self.cmbNwcCoordinates, profile.get('nwc_coordinates'))
            self.chkNwcDivideLevels.IsChecked = profile.get('nwc_divide_levels', True)
            self.chkNwcExportLinks.IsChecked = profile.get('nwc_export_links', False)
            self.chkNwcExportRoomGeometry.IsChecked = profile.get('nwc_export_room_geometry', True)
            self.txtNwcFacetingFactor.Text = str(profile.get('nwc_faceting_factor', '1'))

            self.radImgFit.IsChecked = profile.get('img_fit_to_pixels', True)
            self.radImgZoom.IsChecked = not profile.get('img_fit_to_pixels', True)
            self.txtImgPixels.Text = str(profile.get('img_pixels', '2048'))
            self.radImgVertical.IsChecked = (profile.get('img_direction') == 'Vertical')
            self.radImgHorizontal.IsChecked = (profile.get('img_direction') != 'Vertical')
            self.txtImgZoomPct.Text = str(profile.get('img_zoom_pct', '50'))
            self._set_combo_by_content(self.cmbImgShadedFormat, profile.get('img_shaded_format'))
            self._set_combo_by_content(self.cmbImgNonShadedFormat, profile.get('img_nonshaded_format'))
            self._set_combo_by_content(self.cmbImgDpi, profile.get('img_dpi'))

            self.radSeparateFiles.IsChecked = profile.get('separate_files', True)
            self.radCombineFiles.IsChecked = not profile.get('separate_files', True)
            self.txtOutputFolder.Text = profile.get('output_folder', '')

            view3d_name = profile.get('view3d_name', '')
            view3d_names = list(self.cmb3DView.ItemsSource or [])
            if view3d_name in view3d_names:
                self.cmb3DView.SelectedItem = view3d_name
            elif view3d_names:
                self.cmb3DView.SelectedIndex = 0

            self.naming_entries = profile.get('naming_entries') or [dict(e) for e in DEFAULT_NAMING_ENTRIES]
            self.naming_sep_enabled = profile.get('naming_sep_enabled', True)
            self.naming_sep_char = profile.get('naming_sep_char', '-')
            self.naming_tokens = bake_tokens(self.naming_entries, self.naming_sep_enabled,
                                              self.naming_sep_char)
            self.update_filename_preview()

            self.chkPdf_Changed(None, None)
            self.chkDwg_Changed(None, None)
            self.chkDwf_Changed(None, None)
            self.chkNwc_Changed(None, None)
        finally:
            self._loading_profile = False

    def _set_combo_by_content(self, combo, text):
        if text is None:
            return
        for item in combo.Items:
            content = getattr(item, 'Content', None)
            if content == text:
                combo.SelectedItem = item
                return

    def cmbProfile_SelectionChanged(self, sender, args):
        if self._loading_profile:
            return
        name = self.cmbProfile.SelectedItem
        if not name:
            return
        path = self._profile_path(name)
        if not os.path.isfile(path):
            return
        try:
            with open(path, 'rb') as f:
                xml_text = f.read()
            profile = xml_string_to_profile(xml_text)
            self.apply_profile(profile)
            self.txtStatus.Text = 'Loaded profile "{0}"'.format(name)
        except Exception as ex:
            forms.alert('Could not load profile:\n{0}'.format(ex), title='Bulk Export')

    def btnNewProfile_Click(self, sender, args):
        name = forms.ask_for_string(prompt='Profile name:', title='Save New Profile')
        if not name:
            return
        path = self._profile_path(name)
        if os.path.isfile(path):
            if not forms.alert('A profile named "{0}" already exists. Overwrite?'.format(name),
                               yes=True, no=True):
                return
        try:
            xml_text = profile_to_xml_string(self.collect_profile())
            with open(path, 'wb') as f:
                f.write(xml_text)
            self.refresh_profile_list(select_name=name)
            self.txtStatus.Text = 'Saved profile "{0}"'.format(name)
        except Exception as ex:
            forms.alert('Could not save profile:\n{0}'.format(ex), title='Bulk Export')

    def btnSaveProfile_Click(self, sender, args):
        name = self.cmbProfile.SelectedItem
        if not name:
            self.btnNewProfile_Click(sender, args)
            return
        path = self._profile_path(name)
        try:
            xml_text = profile_to_xml_string(self.collect_profile())
            with open(path, 'wb') as f:
                f.write(xml_text)
            self.txtStatus.Text = 'Saved profile "{0}"'.format(name)
        except Exception as ex:
            forms.alert('Could not save profile:\n{0}'.format(ex), title='Bulk Export')

    def btnDeleteProfile_Click(self, sender, args):
        name = self.cmbProfile.SelectedItem
        if not name:
            forms.alert('Select a profile to delete first.', title='Bulk Export')
            return
        if not forms.alert('Delete profile "{0}"? This cannot be undone.'.format(name),
                           yes=True, no=True):
            return
        try:
            os.remove(self._profile_path(name))
            self.refresh_profile_list()
            self.txtStatus.Text = 'Deleted profile "{0}"'.format(name)
        except Exception as ex:
            forms.alert('Could not delete profile:\n{0}'.format(ex), title='Bulk Export')

    def btnImportProfile_Click(self, sender, args):
        dlg = OpenFileDialog()
        dlg.Filter = 'Bulk Export Profile (*.xml)|*.xml'
        dlg.Title = 'Import Profile (shared by a teammate)'
        if dlg.ShowDialog() != DialogResult.OK:
            return
        try:
            with open(dlg.FileName, 'rb') as f:
                xml_text = f.read()
            profile = xml_string_to_profile(xml_text)
            self.apply_profile(profile)
            self.txtStatus.Text = 'Imported profile from {0}'.format(os.path.basename(dlg.FileName))

            base_name = os.path.splitext(os.path.basename(dlg.FileName))[0]
            if forms.alert('Also save this into your local profile list as "{0}"?'.format(base_name),
                           yes=True, no=True):
                local_path = self._profile_path(base_name)
                with open(local_path, 'wb') as f:
                    f.write(xml_text)
                self.refresh_profile_list(select_name=base_name)
        except Exception as ex:
            forms.alert('Could not import profile:\n{0}'.format(ex), title='Bulk Export')

    def btnExportProfile_Click(self, sender, args):
        dlg = SaveFileDialog()
        dlg.Filter = 'Bulk Export Profile (*.xml)|*.xml'
        dlg.Title = 'Export Profile (to share with your team)'
        dlg.FileName = 'BulkExportProfile.xml'
        if dlg.ShowDialog() != DialogResult.OK:
            return
        try:
            xml_text = profile_to_xml_string(self.collect_profile())
            with open(dlg.FileName, 'wb') as f:
                f.write(xml_text)
            self.txtStatus.Text = 'Exported profile to {0}'.format(dlg.FileName)
            forms.alert('Saved. Share this .xml file with your team - they can load it via '
                        '"Import..." in this tool.', title='Bulk Export')
        except Exception as ex:
            forms.alert('Could not export profile:\n{0}'.format(ex), title='Bulk Export')

    # ----- Settings collection ------------------------------------------------

    def get_settings(self):
        s = {}
        s['formats'] = {
            'pdf': self.chkPdf.IsChecked,
            'dwg': self.chkDwg.IsChecked,
            'dwf': self.chkDwf.IsChecked,
            'nwc': self.chkNwc.IsChecked,
            'ifc': self.chkIfc.IsChecked,
            'img': self.chkImg.IsChecked,
        }
        s['enable_3d'] = self.chkEnable3D.IsChecked
        s['paper_size'] = (self.cmbPaperSize.SelectedItem.Content
                            if self.cmbPaperSize.SelectedItem else 'Sheet Size (as titleblock)')
        s['orientation'] = ('Auto' if self.radOrientAuto.IsChecked else
                             'Portrait' if self.radOrientPortrait.IsChecked else 'Landscape')
        s['placement_center'] = self.radPlaceCenter.IsChecked
        s['offset_x_mm'] = self.txtOffsetX.Text
        s['offset_y_mm'] = self.txtOffsetY.Text
        s['zoom_fit'] = self.radZoomFit.IsChecked
        s['zoom_pct'] = self.txtZoomPct.Text
        s['vector_processing'] = self.radVector.IsChecked
        s['raster_quality'] = (self.cmbRasterQuality.SelectedItem.Content
                                if self.cmbRasterQuality.SelectedItem else 'High')
        s['colors'] = (self.cmbColors.SelectedItem.Content
                        if self.cmbColors.SelectedItem else 'Color')
        s['view_links_blue'] = self.chkViewLinksBlue.IsChecked
        s['hide_ref_planes'] = self.chkHideRefPlanes.IsChecked
        s['hide_unref_tags'] = self.chkHideUnrefTags.IsChecked
        s['hide_scope_boxes'] = self.chkHideScopeBoxes.IsChecked
        s['hide_crop_boundaries'] = self.chkHideCropBoundaries.IsChecked
        s['naming_tokens'] = self.naming_tokens
        s['separate_files'] = self.radSeparateFiles.IsChecked
        s['output_folder'] = self.txtOutputFolder.Text
        s['view3d_name'] = self.cmb3DView.SelectedItem
        s['dwg_setup_name'] = self.cmbDwgSetup.SelectedItem or DEFAULT_DWG_LABEL
        s['dwg_xrefs'] = self.chkDwgXrefs.IsChecked
        s['dwg_clean_pcp'] = self.chkDwgCleanPcp.IsChecked

        # DWF
        s['dwf_is_dwfx'] = self.radDwfxFormat.IsChecked
        s['dwf_cropbox'] = self.chkDwfCropbox.IsChecked
        s['dwf_export_object_data'] = self.chkDwfExportObjectData.IsChecked
        s['dwf_export_areas'] = self.chkDwfExportAreas.IsChecked
        s['dwf_export_textures'] = self.chkDwfExportTextures.IsChecked
        s['dwf_xrefs'] = self.chkDwfXrefs.IsChecked
        s['dwf_image_quality'] = (self.cmbDwfImageQuality.SelectedItem.Content
                                   if self.cmbDwfImageQuality.SelectedItem else 'High')

        # NWC
        s['nwc_coordinates'] = (self.cmbNwcCoordinates.SelectedItem.Content
                                 if self.cmbNwcCoordinates.SelectedItem else 'Shared')
        s['nwc_divide_levels'] = self.chkNwcDivideLevels.IsChecked
        s['nwc_export_links'] = self.chkNwcExportLinks.IsChecked
        s['nwc_export_room_geometry'] = self.chkNwcExportRoomGeometry.IsChecked
        s['nwc_faceting_factor'] = self.txtNwcFacetingFactor.Text

        # IMG
        s['img_fit_to_pixels'] = self.radImgFit.IsChecked
        s['img_pixels'] = self.txtImgPixels.Text
        s['img_direction'] = 'Vertical' if self.radImgVertical.IsChecked else 'Horizontal'
        s['img_zoom_pct'] = self.txtImgZoomPct.Text
        s['img_shaded_format'] = (self.cmbImgShadedFormat.SelectedItem.Content
                                   if self.cmbImgShadedFormat.SelectedItem else 'PNG')
        s['img_nonshaded_format'] = (self.cmbImgNonShadedFormat.SelectedItem.Content
                                      if self.cmbImgNonShadedFormat.SelectedItem else 'PNG')
        s['img_dpi'] = (self.cmbImgDpi.SelectedItem.Content
                         if self.cmbImgDpi.SelectedItem else 'DPI_72')
        return s

    # ----- Export orchestration ------------------------------------------------

    def pump_ui(self):
        """Let WPF process paint/input messages between long API calls."""
        self.Dispatcher.Invoke(System.Action(lambda: None), DispatcherPriority.Background)

    def run_export(self, interactive=True):
        """interactive=False is used by unattended_export.py for scheduled/
        headless runs - it must never show a blocking dialog (forms.alert
        etc.), since there's nobody there to click OK at 2am. Everything
        else about the export logic is identical either way - this is the
        same tested code path the interactive dialog uses."""
        settings = self.get_settings()

        selected = [i.Sheet for i in self.sheet_items if i.IsChecked]
        if not any(settings['formats'].values()):
            if interactive:
                forms.alert('Select at least one export format.', title='Bulk Export')
            else:
                logger.error('Unattended run aborted: no export format selected.')
            return
        if not settings['output_folder']:
            if interactive:
                forms.alert('Choose an output folder first.', title='Bulk Export')
            else:
                logger.error('Unattended run aborted: no output folder set.')
            return
        if not os.path.isdir(settings['output_folder']):
            try:
                os.makedirs(settings['output_folder'])
            except Exception as ex:
                if interactive:
                    forms.alert('Could not create output folder:\n{0}'.format(ex))
                else:
                    logger.error('Unattended run aborted: could not create output folder: {0}'.format(ex))
                return

        needs_sheets = settings['formats']['pdf'] or settings['formats']['dwg'] \
            or settings['formats']['dwf'] or settings['formats']['img']
        if needs_sheets and not selected:
            if interactive:
                forms.alert('Select at least one sheet for PDF/DWG/DWF/IMG export.',
                            title='Bulk Export')
            else:
                logger.error('Unattended run aborted: no sheets selected for PDF/DWG/DWF/IMG.')
            return

        self.results = []
        total_steps = 0
        if needs_sheets:
            total_steps += len(selected) * sum(
                1 for k in ('pdf', 'dwg', 'dwf', 'img') if settings['formats'][k])
        if settings['formats']['ifc']:
            total_steps += 1
        if settings['formats']['nwc']:
            total_steps += 1
        total_steps = max(total_steps, 1)

        done = 0
        self.prgExport.Value = 0

        if settings['formats']['pdf']:
            for sh in selected:
                self.txtStatus.Text = 'PDF: {0}'.format(sh.SheetNumber)
                self.pump_ui()
                self._export_pdf(sh, settings)
                done += 1
                self.prgExport.Value = 100.0 * done / total_steps
                self.pump_ui()

        if settings['formats']['dwg']:
            for sh in selected:
                self.txtStatus.Text = 'DWG: {0}'.format(sh.SheetNumber)
                self.pump_ui()
                self._export_dwg(sh, settings)
                done += 1
                self.prgExport.Value = 100.0 * done / total_steps
                self.pump_ui()

        if settings['formats']['dwf']:
            for sh in selected:
                self.txtStatus.Text = 'DWF: {0}'.format(sh.SheetNumber)
                self.pump_ui()
                self._export_dwf(sh, settings)
                done += 1
                self.prgExport.Value = 100.0 * done / total_steps
                self.pump_ui()

        if settings['formats']['img']:
            for sh in selected:
                self.txtStatus.Text = 'IMG: {0}'.format(sh.SheetNumber)
                self.pump_ui()
                self._export_image(sh, settings)
                done += 1
                self.prgExport.Value = 100.0 * done / total_steps
                self.pump_ui()

        if settings['formats']['ifc']:
            self.txtStatus.Text = 'IFC: whole model'
            self.pump_ui()
            self._export_ifc(settings)
            done += 1
            self.prgExport.Value = 100.0 * done / total_steps

        if settings['formats']['nwc']:
            if settings['enable_3d']:
                self.txtStatus.Text = 'NWC: whole model'
                self.pump_ui()
                self._export_nwc(settings)
            else:
                self.results.append((False, 'NWC', 'Skipped - "Enable 3D view export" switch is OFF.'))
            done += 1
            self.prgExport.Value = 100.0 * done / total_steps

        self.txtStatus.Text = 'Done'
        errors = [r for r in self.results if not r[0]]
        summary = '{0} succeeded, {1} failed/skipped out of {2} operations.'.format(
            len(self.results) - len(errors), len(errors), len(self.results))
        if interactive:
            if errors:
                detail = '\n'.join('- {0}: {1}'.format(name, err) for ok, name, err in errors)
                forms.alert('{0}\n\nDetails:\n{1}'.format(summary, detail),
                            title='Bulk Export - Finished with notes')
            else:
                forms.alert(summary, title='Bulk Export - Finished')
        else:
            logger.info('Unattended export finished: {0}'.format(summary))
            for ok, name, err in self.results:
                if not ok:
                    logger.warn('  FAILED: {0}: {1}'.format(name, err))

    # ----- Per-format export (each wrapped so one failure doesn't stop the batch) -----

    def _configure_common_paper(self, opt, settings):
        """Apply paper size / orientation / placement / zoom to any export
        options object that exposes these properties (PDFExportOptions).

        Each assignment is wrapped individually so that if a given Revit
        version renamed or removed one specific enum member, that one
        setting is skipped (and logged) rather than the whole sheet's
        export failing outright. This is the main defense for running
        across Revit 2024-2027, since a handful of export-related enum
        members have shifted names between versions historically."""

        def try_set(fn, label):
            try:
                fn()
            except Exception as ex:
                logger.warn('Skipped "{0}" (not supported on this Revit version): {1}'.format(label, ex))

        label = settings['paper_size']
        if label in PAPER_FORMAT_MAP:
            try_set(lambda: setattr(opt, 'PaperFormat', getattr(ExportPaperFormat, PAPER_FORMAT_MAP[label])),
                    'Paper Format')
        else:
            # "Sheet Size (as titleblock)" -> Default matches titleblock size
            try_set(lambda: setattr(opt, 'PaperFormat', ExportPaperFormat.Default), 'Paper Format (Default)')

        orientation_map = {
            'Auto': PageOrientationType.Auto,
            'Portrait': PageOrientationType.Portrait,
            'Landscape': PageOrientationType.Landscape,
        }
        try_set(lambda: setattr(opt, 'PaperOrientation', orientation_map[settings['orientation']]),
                'Paper Orientation')

        if settings['placement_center']:
            try_set(lambda: setattr(opt, 'PaperPlacement', PaperPlacementType.Center), 'Paper Placement (Center)')
        else:
            # NOTE: the "offset from corner" placement is exposed as
            # PaperPlacementType.LowerLeft in the Revit API (NOT
            # "OffsetFromCorner" - that name doesn't exist and will throw
            # AttributeError, which is what caused this to fail before).
            try_set(lambda: setattr(opt, 'PaperPlacement', PaperPlacementType.LowerLeft), 'Paper Placement (Offset)')
            try_set(lambda: setattr(opt, 'MarginType', MarginType.UserDefined), 'Margin Type')
            try_set(lambda: setattr(opt, 'UserDefinedMarginX', mm_to_inch(settings['offset_x_mm'])), 'Margin X')
            try_set(lambda: setattr(opt, 'UserDefinedMarginY', mm_to_inch(settings['offset_y_mm'])), 'Margin Y')

        if settings['zoom_fit']:
            # Both ZoomFitType and ZoomType (a separate, similarly-named
            # enum) exist across Revit versions for this same property -
            # try both rather than assuming one.
            try_set_enum_attr(opt, 'ZoomType', 'FitToPage', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Fit to Page)')
        else:
            try_set_enum_attr(opt, 'ZoomType', 'Zoom', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Zoom %)')
            try:
                pct = int(float(settings['zoom_pct']))
            except ValueError:
                pct = 100
            try_set(lambda: setattr(opt, 'ZoomPercentage', pct), 'Zoom Percentage')

    def _export_pdf(self, sheet, settings):
        name = build_filename_from_tokens(settings['naming_tokens'], sheet)
        try:
            opt = PDFExportOptions()
            opt.FileName = name
            opt.Combine = True  # one call = one named file, for full naming control
            self._configure_common_paper(opt, settings)

            opt.RasterQuality = {
                'Low': RasterQualityType.Low,
                'Medium': RasterQualityType.Medium,
                'High': RasterQualityType.High,
                'Presentation': RasterQualityType.Presentation,
            }.get(settings['raster_quality'], RasterQualityType.High)

            opt.ColorDepth = {
                'Color': ColorDepthType.Color,
                'Black Line': ColorDepthType.BlackLine,
                'Grayscale': ColorDepthType.GrayScale,
            }.get(settings['colors'], ColorDepthType.Color)

            opt.HideCropBoundaries = settings['hide_crop_boundaries']
            opt.HideScopeBoxes = settings['hide_scope_boxes']
            opt.HideUnreferencedViewTags = settings['hide_unref_tags']
            opt.HideReferencePlane = settings['hide_ref_planes']
            opt.ViewLinksInBlue = settings['view_links_blue']
            opt.AlwaysUseRaster = settings['vector_processing'] is False

            view_ids = System.Collections.Generic.List[ElementId]([sheet.Id])
            doc.Export(settings['output_folder'], view_ids, opt)
            self.results.append((True, name + '.pdf', None))
        except Exception as ex:
            logger.error('PDF export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
            self.results.append((False, sheet.SheetNumber + ' (PDF)', str(ex)))

    def _get_dwg_options(self, settings):
        """Start from a saved DWG Export Setup if one is selected, otherwise
        Revit's default DWGExportOptions - then apply the xref checkbox."""
        setup_name = settings.get('dwg_setup_name', DEFAULT_DWG_LABEL)
        opt = None
        if setup_name and setup_name != DEFAULT_DWG_LABEL:
            setup_el = self.dwg_setups.get(setup_name)
            if setup_el is not None:
                try:
                    opt = setup_el.GetDWGExportOptions()
                except Exception as ex:
                    logger.warn('Could not read DWG export setup "{0}": {1}'.format(setup_name, ex))
        if opt is None:
            opt = DWGExportOptions()

        # "Export views on sheets and links as external references":
        # closest public-API equivalent is MergedViews (VERIFY on your
        # Revit version - some releases name this differently).
        try:
            opt.MergedViews = not settings.get('dwg_xrefs', False)
        except Exception:
            pass
        return opt

    def _export_dwg(self, sheet, settings):
        name = build_filename_from_tokens(settings['naming_tokens'], sheet)
        try:
            opt = self._get_dwg_options(settings)
            view_ids = System.Collections.Generic.List[ElementId]([sheet.Id])
            doc.Export(settings['output_folder'], name, view_ids, opt)
            if settings.get('dwg_clean_pcp'):
                clean_pcp_file(settings['output_folder'], name)
            self.results.append((True, name + '.dwg', None))
        except Exception as ex:
            logger.error('DWG export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
            self.results.append((False, sheet.SheetNumber + ' (DWG)', str(ex)))

    def _export_dwf(self, sheet, settings):
        if not HAS_DWF:
            self.results.append((False, sheet.SheetNumber + ' (DWF)',
                                  'DWFExportOptions not available in this Revit API version.'))
            return
        name = build_filename_from_tokens(settings['naming_tokens'], sheet)
        try:
            # IMPORTANT: DWFExportOptions is NOT related to PDFExportOptions
            # in the real Revit API (confirmed against Autodesk's own class
            # hierarchy docs) - it does not have PaperFormat, PaperPlacement,
            # ZoomType, RasterQuality, ColorDepth, or the Hide* properties
            # PDF/DWG have. Only the properties below are real for DWF/DWFx.
            if settings.get('dwf_is_dwfx') and HAS_DWFX:
                opt = DWFXExportOptions()
            else:
                opt = DWFExportOptions()

            try_set_attr(opt, 'CropBoxVisible', settings['dwf_cropbox'], 'Cropbox Visible')
            try_set_attr(opt, 'ExportObjectData', settings['dwf_export_object_data'], 'Export Element Properties')
            try_set_attr(opt, 'ExportingAreas', settings['dwf_export_areas'], 'Export Rooms/Spaces/Areas')
            try_set_attr(opt, 'ExportTexture', settings['dwf_export_textures'], 'Export Textures')
            # "Export views on sheets and links as external references":
            # same MergedViews convention as the DWG option.
            try_set_attr(opt, 'MergedViews', not settings.get('dwf_xrefs', False), 'Merged Views (xrefs)')
            # Image quality enum name/values are not fully confirmed across
            # versions - best effort, skipped cleanly if wrong.
            quality_map = {'Low': 1, 'Medium': 2, 'High': 3, 'Default': 0}
            try_set_attr(opt, 'ImageQuality', quality_map.get(settings.get('dwf_image_quality'), 0),
                         'Image Quality')

            view_ids = System.Collections.Generic.List[ElementId]([sheet.Id])
            doc.Export(settings['output_folder'], name, view_ids, opt)
            self.results.append((True, name + ('.dwfx' if settings.get('dwf_is_dwfx') else '.dwf'), None))
        except Exception as ex:
            logger.error('DWF export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
            self.results.append((False, sheet.SheetNumber + ' (DWF)', str(ex)))

    def _export_image(self, sheet, settings):
        name = build_filename_from_tokens(settings['naming_tokens'], sheet)
        try:
            opt = ImageExportOptions()
            opt.ExportRange = ExportRange.SetOfViews
            opt.SetViewsAndSheets(
                System.Collections.Generic.List[ElementId]([sheet.Id]))
            opt.FilePath = os.path.join(settings['output_folder'], name)

            if settings.get('img_fit_to_pixels', True):
                try_set_enum_attr(opt, 'ZoomType', 'FitToPage', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Fit)')
                try:
                    pixels = int(float(settings.get('img_pixels', 2048)))
                except (TypeError, ValueError):
                    pixels = 2048
                try_set_attr(opt, 'PixelSize', pixels, 'Pixel Size')
            else:
                try_set_enum_attr(opt, 'ZoomType', 'Zoom', _ZOOM_ENUM_CANDIDATES, 'Zoom Type (Zoom %)')
                try:
                    zoom_pct = int(float(settings.get('img_zoom_pct', 50)))
                except (TypeError, ValueError):
                    zoom_pct = 50
                try_set_attr(opt, 'Zoom', zoom_pct, 'Zoom Percentage')

            direction = FitDirectionType.Vertical if settings.get('img_direction') == 'Vertical' else FitDirectionType.Horizontal
            try_set_attr(opt, 'FitDirection', direction, 'Fit Direction')

            file_type_map = {
                'PNG': ImageFileType.PNG,
                'JPEG': getattr(ImageFileType, 'JPEGLossless', ImageFileType.PNG),
                'BMP': getattr(ImageFileType, 'BMP', ImageFileType.PNG),
                'TARGA': getattr(ImageFileType, 'TARGA', ImageFileType.PNG),
            }
            # "Non Shaded Views" (wireframe/hidden-line) -> HLRandWFViewsFileType
            try_set_attr(opt, 'HLRandWFViewsFileType',
                         file_type_map.get(settings.get('img_nonshaded_format'), ImageFileType.PNG),
                         'Non-Shaded Views Format')
            # "Shaded Views" -> ShadowViewsFileType
            try_set_attr(opt, 'ShadowViewsFileType',
                         file_type_map.get(settings.get('img_shaded_format'), ImageFileType.PNG),
                         'Shaded Views Format')

            dpi_map = {
                'DPI_72': ImageResolution.DPI_72, 'DPI_150': ImageResolution.DPI_150,
                'DPI_300': ImageResolution.DPI_300, 'DPI_600': ImageResolution.DPI_600,
            }
            try_set_attr(opt, 'ImageResolution', dpi_map.get(settings.get('img_dpi'), ImageResolution.DPI_72),
                         'Raster Image Quality')

            # NOTE: Revit auto-appends the view name / an index suffix to
            # FilePath when exporting a SetOfViews - exact single-sheet
            # name control isn't guaranteed here. Rename after export if
            # you need the literal token-built name.
            doc.ExportImage(opt)
            self.results.append((True, name + ' (image, approx. name)', None))
        except Exception as ex:
            logger.error('Image export failed for {0}: {1}'.format(sheet.SheetNumber, ex))
            self.results.append((False, sheet.SheetNumber + ' (IMG)', str(ex)))

    def _export_ifc(self, settings):
        if not HAS_IFC:
            self.results.append((False, 'IFC', 'IFC export module not loaded/available.'))
            return
        name = sanitize_filename(get_project_number(doc) or doc.Title)
        try:
            opt = IFCExportOptions()
            # IFC export is whole-model; per-sheet naming tokens don't apply.
            doc.Export(settings['output_folder'], name, opt)
            self.results.append((True, name + '.ifc', None))
        except Exception as ex:
            logger.error('IFC export failed: {0}'.format(ex))
            self.results.append((False, 'IFC', str(ex)))

    def _export_nwc(self, settings):
        if not HAS_NWC:
            self.results.append((False, 'NWC',
                                  'NavisworksExportOptions not found - install the '
                                  '"Navisworks Exporter for Revit" add-in separately.'))
            return
        if not settings['view3d_name']:
            self.results.append((False, 'NWC', 'No 3D view available to export.'))
            return
        name = sanitize_filename(get_project_number(doc) or doc.Title)
        try:
            view3d = next(v for v in self.view3d_list if v.Name == settings['view3d_name'])
            opt = NavisworksExportOptions()

            # NOTE: ExportScope takes the NavisworksExportScope enum, NOT a
            # raw integer (confirmed against Autodesk sample code) - the
            # earlier "ExportScope = 0" was silently wrong.
            try_set_attr(opt, 'ExportScope', NavisworksExportScope.View, 'Export Scope (View)')
            try_set_attr(opt, 'ViewId', view3d.Id, 'View Id')

            coord_map = {'Shared': 'Shared', 'Internal': 'Internal'}
            coord_name = coord_map.get(settings.get('nwc_coordinates'), 'Shared')
            coord_value = getattr(NavisworksCoordinates, coord_name, getattr(NavisworksCoordinates, 'Shared', None))
            if coord_value is not None:
                try_set_attr(opt, 'Coordinates', coord_value, 'Coordinates')

            try_set_attr(opt, 'DivideFileIntoLevels', settings.get('nwc_divide_levels', True), 'Divide File Into Levels')
            try_set_attr(opt, 'ExportLinks', settings.get('nwc_export_links', False), 'Convert Linked Files')
            try_set_attr(opt, 'ExportRoomGeometry', settings.get('nwc_export_room_geometry', True), 'Export Room Geometry')

            try:
                facet = float(settings.get('nwc_faceting_factor', 1))
            except (TypeError, ValueError):
                facet = 1.0
            try_set_attr(opt, 'FacetingFactor', facet, 'Faceting Factor')

            doc.Export(settings['output_folder'], name, opt)
            self.results.append((True, name + '.nwc', None))
        except Exception as ex:
            logger.error('NWC export failed: {0}'.format(ex))
            self.results.append((False, 'NWC', str(ex)))


if __name__ == '__main__':
    BulkExportWindow(XAML_FILE).ShowDialog()
