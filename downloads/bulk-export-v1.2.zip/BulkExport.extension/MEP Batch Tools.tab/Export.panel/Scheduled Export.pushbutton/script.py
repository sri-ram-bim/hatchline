# -*- coding: utf-8 -*-
"""
Run Scheduled Export Now
--------------------------
Manually triggers the exact same logic Task Scheduler will run
unattended (lib/scheduled_export.py), so you can verify your
scheduled_export_config.json and saved profile actually work before
trusting them to run at 3am with nobody watching.

This button shows a small summary at the end (via pyRevit's output
window) since a human IS present when clicking this button - the
headless/CLI path (scheduled_export.py run via `pyrevit run`) skips
that and only writes to the log file, since nobody's there to see it.
"""

import os
import sys

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_DIR = os.path.join(THIS_DIR, '..', '..', '..', 'lib')
LIB_DIR = os.path.abspath(LIB_DIR)
if LIB_DIR not in sys.path:
    sys.path.append(LIB_DIR)

from pyrevit import forms, script

output = script.get_output()

if not forms.alert(
        'This runs your saved scheduled_export_config.json against the '
        'CURRENTLY OPEN model, using whichever profile is configured. '
        'Files will actually be exported to the configured output folder.\n\n'
        'Continue?', yes=True, no=True, title='Run Scheduled Export Now'):
    script.exit()

import scheduled_export  # noqa: E402 - runs main() as a side effect on import

output.print_md('### Scheduled export test run complete')
output.print_md('Check the log file written to `%APPDATA%\\BulkExportTools\\Logs\\` '
                 'for full details (same log file the unattended/Task Scheduler run would produce).')
