# -*- coding: utf-8 -*-
"""Elements Count - counts elements grouped by Category. Uses the current
selection if anything is selected, otherwise counts the whole model."""
__title__ = "Elements\nCount"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Counts elements by Category - from current selection, or the whole model if nothing is selected."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import FilteredElementCollector
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


def count_by_category(elements):
    counts = {}
    for el in elements:
        try:
            cat_name = el.Category.Name if el.Category else "(No Category)"
        except Exception:
            cat_name = "(No Category)"
        counts[cat_name] = counts.get(cat_name, 0) + 1
    return counts


def main():
    sel_ids = list(uidoc.Selection.GetElementIds())

    if sel_ids:
        elements = [doc.GetElement(eid) for eid in sel_ids]
        elements = [e for e in elements if e is not None]
        source_label = "Current Selection ({0} elements)".format(len(elements))
    else:
        elements = FilteredElementCollector(doc).WhereElementIsNotElementType().ToElements()
        source_label = "Whole Model ({0} elements)".format(len(elements))

    counts = count_by_category(elements)
    if not counts:
        forms.alert("Count panna edhuvum element kedaikala.", exitscript=True)

    total = sum(counts.values())

    output.print_md("## Elements Count - {0}".format(source_label))
    output.print_md("| Category | Count |")
    output.print_md("|---|---|")
    for cat_name in sorted(counts.keys()):
        output.print_md("| {0} | {1} |".format(cat_name, counts[cat_name]))
    output.print_md("| **TOTAL** | **{0}** |".format(total))

    summary_lines = ["{0}: {1}".format(cat, counts[cat]) for cat in sorted(counts.keys())]
    summary_lines.append("")
    summary_lines.append("TOTAL: {0}".format(total))
    forms.alert("{0}\n\n{1}".format(source_label, "\n".join(summary_lines)), title="Elements Count")


if __name__ == "__main__":
    main()
