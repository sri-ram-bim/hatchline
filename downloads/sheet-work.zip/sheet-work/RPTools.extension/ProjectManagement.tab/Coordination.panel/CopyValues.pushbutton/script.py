# -*- coding: utf-8 -*-
"""Copy Values - select multiple elements, pick one common parameter, type a
value once, apply that same value to all of them in a single transaction."""
__title__ = "Copy\nValues"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Select multiple elements, pick a common parameter, type one value, apply it to all selected elements."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import Transaction, StorageType, ElementId
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


def get_writable_param_names(element):
    names = []
    try:
        for p in element.Parameters:
            try:
                if p.IsReadOnly:
                    continue
                names.append(p.Definition.Name)
            except Exception:
                pass
    except Exception:
        pass
    return set(names)


def set_value(target_el, param_name, value_text):
    tp = target_el.LookupParameter(param_name)
    if tp is None:
        return False, "parameter not found"
    if tp.IsReadOnly:
        return False, "read-only"
    try:
        st = tp.StorageType
        if st == StorageType.String:
            tp.Set(value_text)
        elif st == StorageType.Double:
            # SetValueString respects the parameter's display units (mm, ft, etc.)
            ok = tp.SetValueString(value_text)
            if not ok:
                tp.Set(float(value_text))
        elif st == StorageType.Integer:
            tp.Set(int(float(value_text)))
        elif st == StorageType.ElementId:
            tp.Set(ElementId(int(value_text)))
        else:
            return False, "unsupported storage type"
        return True, None
    except Exception as ex:
        return False, str(ex)


def main():
    sel_ids = list(uidoc.Selection.GetElementIds())
    if not sel_ids:
        forms.alert("Modelinla eppadiyum 2 or more elements select pannunga, appuram indha tool run pannunga.", exitscript=True)

    elements = [doc.GetElement(eid) for eid in sel_ids]
    elements = [e for e in elements if e is not None]
    if len(elements) < 2:
        forms.alert("Kuraindhathu 2 elements select pannunga (broadcast pannurathukku).", exitscript=True)

    common_params = get_writable_param_names(elements[0])
    for e in elements[1:]:
        common_params &= get_writable_param_names(e)

    if not common_params:
        forms.alert("Select panna elements-la common ah writable parameter edhuvum illa.", exitscript=True)

    param_name = forms.SelectFromList.show(
        sorted(common_params),
        title="Copy Values - edha parameter-ku value set pannanum?",
        multiselect=False
    )
    if not param_name:
        script.exit()

    value_text = forms.ask_for_string(
        default="", prompt="'{0}' ku set panna value type pannunga:".format(param_name),
        title="Copy Values"
    )
    if value_text is None:
        script.exit()

    t = Transaction(doc, "Copy Values (RPTools)")
    t.Start()
    ok_count = 0
    fail_log = []
    try:
        for e in elements:
            success, err = set_value(e, param_name, value_text)
            if success:
                ok_count += 1
            else:
                fail_log.append("Element {0}: {1}".format(e.Id.IntegerValue, err))
        t.Commit()
    except Exception:
        t.RollBack()
        raise

    output.print_md("### Copy Values - Done")
    output.print_md("Parameter: **{0}**  |  Value: `{1}`".format(param_name, value_text))
    output.print_md("Applied to {0} of {1} element(s).".format(ok_count, len(elements)))
    if fail_log:
        output.print_md("Failed:")
        for line in fail_log:
            output.print_md("- {0}".format(line))

    forms.alert("'{0}' = '{1}' -> {2} of {3} element(s)-ku apply aayiduchu.\n\n{4}".format(
        param_name, value_text, ok_count, len(elements),
        "Konjam fail aayiduchu - output panel-la details paar." if fail_log else "Ellame success!"
    ))


if __name__ == "__main__":
    main()
