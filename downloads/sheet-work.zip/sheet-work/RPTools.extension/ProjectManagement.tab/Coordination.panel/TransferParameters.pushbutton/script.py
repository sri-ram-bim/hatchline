# -*- coding: utf-8 -*-
"""Transfer Parameters - pick one source element, pick one or more target
elements, choose which parameter(s) to copy from source to every target."""
__title__ = "Transfer\nParameters"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Pick a source element, then target element(s), then choose parameter(s) to copy from source to all targets."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import Transaction, StorageType, ElementId
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


def get_writable_param_names(element):
    names = []
    try:
        for p in element.Parameters:
            try:
                if p.IsReadOnly:
                    continue
                names.append(p.Definition.Name)
            except Exception:
                pass
    except Exception:
        pass
    return set(names)


def copy_param_value(source_el, target_el, param_name):
    sp = source_el.LookupParameter(param_name)
    tp = target_el.LookupParameter(param_name)
    if sp is None or tp is None:
        return False, "parameter not found on one side"
    if tp.IsReadOnly:
        return False, "target parameter is read-only"

    try:
        st = sp.StorageType
        if st == StorageType.String:
            tp.Set(sp.AsString() or "")
        elif st == StorageType.Double:
            tp.Set(sp.AsDouble())
        elif st == StorageType.Integer:
            tp.Set(sp.AsInteger())
        elif st == StorageType.ElementId:
            tp.Set(sp.AsElementId())
        else:
            return False, "unsupported storage type"
        return True, None
    except Exception as ex:
        return False, str(ex)


def main():
    try:
        source_ref = uidoc.Selection.PickObject(
            ObjectType.Element,
            "SOURCE element ah pick pannunga (edhu la irunthu copy pannanumo)"
        )
    except Exception:
        script.exit()
    source_el = doc.GetElement(source_ref.ElementId)

    try:
        target_refs = uidoc.Selection.PickObjects(
            ObjectType.Element,
            "TARGET element(s) ah pick pannunga (edhu ku copy pannanumo), Finish click pannunga mudinjadhum"
        )
    except Exception:
        script.exit()

    target_els = [doc.GetElement(r.ElementId) for r in target_refs]
    target_els = [e for e in target_els if e is not None and e.Id != source_el.Id]
    if not target_els:
        forms.alert("Valid target element(s) select pannala.", exitscript=True)

    source_params = get_writable_param_names(source_el)
    common_params = set(source_params)
    for t in target_els:
        common_params &= get_writable_param_names(t)

    if not common_params:
        forms.alert("Source-um target(s)-um-la common ah writable parameter edhuvum illa.", exitscript=True)

    chosen = forms.SelectFromList.show(
        sorted(common_params),
        title="Transfer Parameters - edha edha copy pannanum?",
        multiselect=True
    )
    if not chosen:
        script.exit()

    t = Transaction(doc, "Transfer Parameters (RPTools)")
    t.Start()
    ok_count = 0
    fail_log = []
    try:
        for target_el in target_els:
            for pname in chosen:
                success, err = copy_param_value(source_el, target_el, pname)
                if success:
                    ok_count += 1
                else:
                    fail_log.append("{0} -> Element {1}: {2}".format(pname, target_el.Id.IntegerValue, err))
        t.Commit()
    except Exception:
        t.RollBack()
        raise

    output.print_md("### Transfer Parameters - Done")
    output.print_md("Source: Element `{0}`".format(source_el.Id.IntegerValue))
    output.print_md("Targets: {0} element(s)".format(len(target_els)))
    output.print_md("Parameters copied: {0}".format(", ".join(chosen)))
    output.print_md("Successful copies: **{0}**".format(ok_count))
    if fail_log:
        output.print_md("Failed:")
        for line in fail_log:
            output.print_md("- {0}".format(line))

    forms.alert("{0} parameter value(s) transfer aayiduchu, {1} target element(s)-ku.\n\n{2}".format(
        ok_count, len(target_els),
        "Konjam fail aayiduchu - output panel-la details paar." if fail_log else "Ellame success!"
    ))


if __name__ == "__main__":
    main()
