# -*- coding: utf-8 -*-
"""Copy (or move) selected legend viewports / viewports from the active sheet to many target sheets,
keeping the same position on each target sheet."""
__title__ = "Copy/Move\nLegends"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Select legend/viewport(s) on the active sheet, pick target sheets, Copy or Move them to the same position on every target sheet."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import (
    Transaction, Viewport, ViewSheet, FilteredElementCollector, ViewType
)
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


def get_selected_viewports():
    sel_ids = uidoc.Selection.GetElementIds()
    vports = []
    for eid in sel_ids:
        el = doc.GetElement(eid)
        if isinstance(el, Viewport):
            vports.append(el)
    return vports


def get_all_sheets(exclude_id):
    sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    return sorted([s for s in sheets if s.Id != exclude_id and not s.IsPlaceholder],
                  key=lambda s: s.SheetNumber)


class SheetItem(forms.TemplateListItem):
    @property
    def name(self):
        return "{0}  -  {1}".format(self.item.SheetNumber, self.item.Name)


def main():
    active_view = doc.ActiveView
    if not isinstance(active_view, ViewSheet):
        forms.alert("Oru Sheet view open pannі, adhula legend/viewport select pannі run pannunga.", exitscript=True)

    source_vports = get_selected_viewports()
    if not source_vports:
        forms.alert(
            "Sheet-la legend/view viewport(s) select pannunga (click pannі), appuram tool run pannunga.",
            exitscript=True
        )

    other_sheets = get_all_sheets(active_view.Id)
    if not other_sheets:
        forms.alert("Vera target sheets illa model-la.", exitscript=True)

    sheet_items = [SheetItem(s) for s in other_sheets]
    target_sheets = forms.SelectFromList.show(
        sheet_items, title="Select Target Sheets", button_name="Next", multiselect=True
    )
    if not target_sheets:
        script.exit()

    mode = forms.CommandSwitchWindow.show(
        ["Copy to all target sheets", "Move to target sheets (remove from source)"],
        message="Copy or Move?"
    )
    if not mode:
        script.exit()

    is_move = mode.startswith("Move")

    t = Transaction(doc, "Copy/Move Viewports to Sheets")
    t.Start()
    count = 0
    errors = []
    try:
        for vp in source_vports:
            view_id = vp.ViewId
            center = vp.GetBoxCenter()

            for sheet in target_sheets:
                try:
                    if Viewport.CanAddViewToSheet(doc, sheet.Id, view_id):
                        new_vp = Viewport.Create(doc, sheet.Id, view_id, center)
                        count += 1
                        output.print_md("Placed view on **{0} - {1}**".format(sheet.SheetNumber, sheet.Name))
                    else:
                        errors.append("View already on sheet {0}, or cannot be placed twice on same sheet (Revit rule: same view can't repeat on multiple sheets — use a Legend view, which CAN repeat, or duplicate the view).".format(sheet.SheetNumber))
                except Exception as ex:
                    errors.append("{0}: {1}".format(sheet.SheetNumber, str(ex)))

            if is_move:
                doc.Delete(vp.Id)

        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error: {0}".format(str(ex)))
        return

    msg = "{0} viewport(s) placed across {1} sheet(s).".format(count, len(target_sheets))
    if errors:
        msg += "\n\nNotes:\n" + "\n".join(set(errors))
    forms.alert(msg)


if __name__ == "__main__":
    main()
