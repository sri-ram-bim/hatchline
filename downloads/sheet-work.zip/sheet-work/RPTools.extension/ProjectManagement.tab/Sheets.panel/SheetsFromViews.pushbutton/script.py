# -*- coding: utf-8 -*-
"""Create one sheet per selected view and place the view on it (bulk)."""
__title__ = "Sheets\nFrom Views"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Select views -> pick a titleblock -> creates one sheet per view with the view placed on it."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import (
    FilteredElementCollector, View, ViewSheet, FamilySymbol,
    BuiltInCategory, Viewport, XYZ, Transaction, ViewType
)
from pyrevit import revit, forms, script

doc = revit.doc
output = script.get_output()


def get_placeable_views():
    views = FilteredElementCollector(doc).OfClass(View).ToElements()
    result = []
    for v in views:
        if v.IsTemplate:
            continue
        if v.ViewType in (ViewType.DrawingSheet, ViewType.Internal,
                           ViewType.ProjectBrowser, ViewType.SystemBrowser,
                           ViewType.Undefined, ViewType.Schedule):
            continue
        result.append(v)
    return sorted(result, key=lambda x: x.Name)


def get_titleblocks():
    return FilteredElementCollector(doc)\
        .OfCategory(BuiltInCategory.OST_TitleBlocks)\
        .WhereElementIsElementType()\
        .ToElements()


class ViewItem(forms.TemplateListItem):
    @property
    def name(self):
        return "{0}  [{1}]".format(self.item.Name, self.item.ViewType)


def main():
    views = get_placeable_views()
    if not views:
        forms.alert("Placeable views illa model-la.", exitscript=True)

    view_items = [ViewItem(v) for v in views]
    selected_views = forms.SelectFromList.show(
        view_items, title="Select Views to place on new Sheets",
        button_name="Next", multiselect=True
    )
    if not selected_views:
        script.exit()

    titleblocks = get_titleblocks()
    if not titleblocks:
        forms.alert("Model la titleblock illa. Titleblock family load pannunga first.", exitscript=True)

    tb_map = {}
    for t in titleblocks:
        try:
            fam_name = t.Family.Name
        except Exception:
            fam_name = "Titleblock"
        try:
            type_name = t.get_Parameter(
                __import__("Autodesk.Revit.DB").BuiltInParameter.SYMBOL_NAME_PARAM
            ).AsString()
        except Exception:
            type_name = t.Name
        label = "{0} : {1}".format(fam_name, type_name)
        tb_map[label] = t

    tb_choice = forms.SelectFromList.show(
        sorted(tb_map.keys()), title="Select Titleblock", multiselect=False
    )
    if not tb_choice:
        script.exit()
    tb_type = tb_map[tb_choice]

    start_number = forms.ask_for_string(
        default="A-101", prompt="Starting sheet number (auto increments):",
        title="Sheet Numbering"
    )
    if not start_number:
        script.exit()

    import re
    m = re.match(r'^(.*?)(\d+)$', start_number)
    if m:
        prefix, num_str = m.group(1), m.group(2)
        pad = len(num_str)
        start_num = int(num_str)
    else:
        prefix, pad, start_num = start_number, 0, 1

    t = Transaction(doc, "Bulk Create Sheets From Views")
    t.Start()
    created = 0
    try:
        if not tb_type.IsActive:
            tb_type.Activate()

        for i, v in enumerate(selected_views):
            sheet_num = "{0}{1}".format(prefix, str(start_num + i).zfill(pad)) if pad else "{0}{1}".format(prefix, start_num + i)
            new_sheet = ViewSheet.Create(doc, tb_type.Id)
            new_sheet.SheetNumber = sheet_num
            new_sheet.Name = v.Name

            # place view centered on sheet (rough center point; adjust in Revit after)
            center = XYZ(1.0, 0.6, 0)
            try:
                if Viewport.CanAddViewToSheet(doc, new_sheet.Id, v.Id):
                    Viewport.Create(doc, new_sheet.Id, v.Id, center)
                    created += 1
                    output.print_md("Created sheet **{0} - {1}** with view **{2}**".format(
                        sheet_num, new_sheet.Name, v.Name))
                else:
                    output.print_md("⚠ Could not place view **{0}** (already on a sheet, or a Legend which needs Copy/Paste flow, or schedule).".format(v.Name))
            except Exception as ex:
                output.print_md("⚠ Skipped **{0}**: {1}".format(v.Name, str(ex)))

        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error: {0}".format(str(ex)))
        return

    forms.alert("{0} sheets created!\n\nNote: view position on sheet is a default center point — adjust the viewport position on each sheet as needed.".format(created))


if __name__ == "__main__":
    main()
