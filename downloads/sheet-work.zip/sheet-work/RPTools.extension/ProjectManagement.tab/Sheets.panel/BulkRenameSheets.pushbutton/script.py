# -*- coding: utf-8 -*-
"""Bulk rename sheet Names/Numbers - Find & Replace, Add Prefix/Suffix, or import from a mapping txt/csv file."""
__title__ = "Bulk Rename\nSheets"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Bulk rename Sheet Number and/or Sheet Name: Find & Replace, Add Prefix/Suffix, or import a mapping file (CSV: OldNumber,NewNumber,NewName)."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import FilteredElementCollector, ViewSheet, Transaction
from pyrevit import revit, forms, script

doc = revit.doc
output = script.get_output()


def get_all_sheets():
    sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    return sorted([s for s in sheets if not s.IsPlaceholder], key=lambda s: s.SheetNumber)


class SheetItem(forms.TemplateListItem):
    @property
    def name(self):
        return "{0}  -  {1}".format(self.item.SheetNumber, self.item.Name)


def mode_find_replace(sheets):
    target_field = forms.CommandSwitchWindow.show(
        ["Sheet Number", "Sheet Name"], message="Find & Replace on which field?"
    )
    if not target_field:
        return

    find_txt = forms.ask_for_string(default="", prompt="Find text:", title="Find & Replace")
    if find_txt is None:
        return
    replace_txt = forms.ask_for_string(default="", prompt="Replace with:", title="Find & Replace")
    if replace_txt is None:
        return

    t = Transaction(doc, "Bulk Rename Sheets - Find & Replace")
    t.Start()
    count = 0
    try:
        for s in sheets:
            if target_field == "Sheet Number":
                if find_txt in s.SheetNumber:
                    s.SheetNumber = s.SheetNumber.replace(find_txt, replace_txt)
                    count += 1
            else:
                if find_txt in s.Name:
                    s.Name = s.Name.replace(find_txt, replace_txt)
                    count += 1
        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error: {0}".format(str(ex)))
        return
    forms.alert("{0} sheets updated.".format(count))


def mode_prefix_suffix(sheets):
    target_field = forms.CommandSwitchWindow.show(
        ["Sheet Number", "Sheet Name"], message="Add Prefix/Suffix to which field?"
    )
    if not target_field:
        return

    prefix = forms.ask_for_string(default="", prompt="Prefix (leave blank if none):", title="Prefix")
    if prefix is None:
        return
    suffix = forms.ask_for_string(default="", prompt="Suffix (leave blank if none):", title="Suffix")
    if suffix is None:
        return

    t = Transaction(doc, "Bulk Rename Sheets - Prefix/Suffix")
    t.Start()
    count = 0
    try:
        for s in sheets:
            if target_field == "Sheet Number":
                s.SheetNumber = "{0}{1}{2}".format(prefix, s.SheetNumber, suffix)
            else:
                s.Name = "{0}{1}{2}".format(prefix, s.Name, suffix)
            count += 1
        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error: {0}".format(str(ex)))
        return
    forms.alert("{0} sheets updated.".format(count))


def mode_import_mapping(sheets):
    file_path = forms.pick_file(file_ext="csv", title="Select mapping CSV file (OldNumber,NewNumber,NewName)")
    if not file_path:
        return

    sheet_by_number = {s.SheetNumber: s for s in sheets}

    updated, skipped = 0, []
    t = Transaction(doc, "Bulk Rename Sheets - Import Mapping")
    t.Start()
    try:
        with open(file_path, "r") as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line or line.lower().startswith("oldnumber"):
                    continue
                parts = [p.strip() for p in line.split(",")]
                if len(parts) < 2:
                    skipped.append("Line {0}: invalid format".format(line_num))
                    continue
                old_num = parts[0]
                new_num = parts[1] if len(parts) > 1 else ""
                new_name = parts[2] if len(parts) > 2 else ""

                sheet = sheet_by_number.get(old_num)
                if not sheet:
                    skipped.append("'{0}' not found in model".format(old_num))
                    continue

                if new_num:
                    sheet.SheetNumber = new_num
                if new_name:
                    sheet.Name = new_name
                updated += 1

        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error reading/applying file: {0}".format(str(ex)))
        return

    msg = "{0} sheets updated from mapping file.".format(updated)
    if skipped:
        msg += "\n\nSkipped:\n" + "\n".join(skipped[:20])
        if len(skipped) > 20:
            msg += "\n... and {0} more".format(len(skipped) - 20)
    forms.alert(msg)


def main():
    all_sheets = get_all_sheets()
    if not all_sheets:
        forms.alert("Model-la sheets illa.", exitscript=True)

    mode = forms.CommandSwitchWindow.show(
        ["Find & Replace (selected sheets)",
         "Add Prefix/Suffix (selected sheets)",
         "Import Mapping CSV (bulk, all at once)"],
        message="Choose rename mode:"
    )
    if not mode:
        script.exit()

    if mode.startswith("Import"):
        mode_import_mapping(all_sheets)
        return

    # for find&replace / prefix-suffix -> let user pick which sheets to affect
    sheet_items = [SheetItem(s) for s in all_sheets]
    selected = forms.SelectFromList.show(
        sheet_items, title="Select Sheets to Rename", button_name="Next", multiselect=True
    )
    if not selected:
        script.exit()

    if mode.startswith("Find"):
        mode_find_replace(selected)
    else:
        mode_prefix_suffix(selected)


if __name__ == "__main__":
    main()
