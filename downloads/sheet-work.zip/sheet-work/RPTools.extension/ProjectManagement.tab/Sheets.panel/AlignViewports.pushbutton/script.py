# -*- coding: utf-8 -*-
"""Align Viewports across MULTIPLE sheets - Archilizer style.
Pick ONE reference viewport on the current sheet, then apply that exact
paper-space position to the matching viewport on every target sheet.
"""
__title__ = "Align\nViewports"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = ("Select ONE viewport on the active sheet as the reference position, "
           "pick target sheets, and this tool moves the viewport on each target sheet "
           "to the exact same paper position as the reference (Archilizer-style cross-sheet align).")

import traceback
import clr

clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import (
    Transaction, Viewport, ViewSheet, FilteredElementCollector
)
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


def get_selected_viewports():
    sel_ids = uidoc.Selection.GetElementIds()
    vports = []
    for eid in sel_ids:
        el = doc.GetElement(eid)
        if isinstance(el, Viewport):
            vports.append(el)
    return vports


def get_all_sheets(exclude_id):
    sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    return sorted([s for s in sheets if s.Id != exclude_id and not s.IsPlaceholder],
                  key=lambda s: s.SheetNumber)


def get_viewports_on_sheet(sheet):
    return list(FilteredElementCollector(doc, sheet.Id).OfClass(Viewport).ToElements())


class SheetItem(forms.TemplateListItem):
    @property
    def name(self):
        return "{0}  -  {1}".format(self.item.SheetNumber, self.item.Name)


def view_label(vp):
    v = doc.GetElement(vp.ViewId)
    try:
        return "{0}  [{1}]".format(v.Name, v.ViewType)
    except Exception:
        return v.Name


def main():
    active_view = doc.ActiveView
    if not isinstance(active_view, ViewSheet):
        forms.alert(
            "Reference viewport irukura Sheet-a open pannunga, adhula andha viewport-a "
            "SELECT pannitu (click pannunga) intha tool run pannunga.",
            exitscript=True
        )

    ref_vps = get_selected_viewports()
    if len(ref_vps) != 1:
        forms.alert(
            "Exactly ONE viewport select pannunga andha reference sheet-la "
            "(idhoda position thaan ella target sheets-kkum copy aagum).\n\n"
            "Currently selected viewports: {0}".format(len(ref_vps)),
            exitscript=True
        )

    ref_vp = ref_vps[0]
    ref_center = ref_vp.GetBoxCenter()
    ref_sheet = active_view
    ref_view = doc.GetElement(ref_vp.ViewId)

    output.print_md("### Reference: Sheet **{0} - {1}**, View **{2}**".format(
        ref_sheet.SheetNumber, ref_sheet.Name, ref_view.Name))

    other_sheets = get_all_sheets(ref_sheet.Id)
    if not other_sheets:
        forms.alert("Vera target sheets illa model-la.", exitscript=True)

    sheet_items = [SheetItem(s) for s in other_sheets]
    target_sheets = forms.SelectFromList.show(
        sheet_items,
        title="Select Target Sheets to align (same position as reference)",
        button_name="Next",
        multiselect=True
    )
    if not target_sheets:
        script.exit()

    try:
        t = Transaction(doc, "Align Viewports Across Sheets")
        t.Start()

        aligned = []
        skipped = []
        ambiguous_resolved = []

        for sheet in target_sheets:
            vports = get_viewports_on_sheet(sheet)

            if len(vports) == 0:
                skipped.append("{0} - {1}: no viewports on this sheet".format(sheet.SheetNumber, sheet.Name))
                continue

            elif len(vports) == 1:
                target_vp = vports[0]

            else:
                # multiple viewports on this sheet - ask user which one to align
                choice_labels = ["{0}. {1}".format(i + 1, view_label(vp)) for i, vp in enumerate(vports)]
                pick = forms.SelectFromList.show(
                    choice_labels,
                    title="Sheet {0} has {1} viewports - pick which one to align".format(
                        sheet.SheetNumber, len(vports)),
                    multiselect=False
                )
                if not pick:
                    skipped.append("{0} - {1}: user skipped (multiple viewports, none chosen)".format(
                        sheet.SheetNumber, sheet.Name))
                    continue
                idx = choice_labels.index(pick)
                target_vp = vports[idx]
                ambiguous_resolved.append("{0} -> {1}".format(sheet.SheetNumber, view_label(target_vp)))

            target_vp.SetBoxCenter(ref_center)
            aligned.append("{0} - {1}  (view: {2})".format(
                sheet.SheetNumber, sheet.Name, view_label(target_vp)))

        t.Commit()

    except Exception:
        try:
            t.RollBack()
        except Exception:
            pass
        err_text = traceback.format_exc()
        output.print_md("# ERROR")
        output.print_md("```\n{0}\n```".format(err_text))
        forms.alert("Error during align: {0}".format(err_text.strip().split(chr(10))[-1]))
        return

    output.print_md("### Aligned ({0}):".format(len(aligned)))
    for a in aligned:
        output.print_md("- " + a)

    if skipped:
        output.print_md("### Skipped ({0}):".format(len(skipped)))
        for s in skipped:
            output.print_md("- " + s)

    msg = "{0} sheet(s) aligned to reference position.".format(len(aligned))
    if skipped:
        msg += "\n{0} sheet(s) skipped - check output panel for details.".format(len(skipped))
    forms.alert(msg)


if __name__ == "__main__":
    main()
