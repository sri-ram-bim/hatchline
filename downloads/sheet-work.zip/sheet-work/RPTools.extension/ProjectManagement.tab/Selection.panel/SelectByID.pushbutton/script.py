# -*- coding: utf-8 -*-
"""Select / Identify element(s) by Element ID - in host model or inside a linked model."""
__title__ = "Select\nBy ID"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Enter one or more Element IDs (comma or space separated) to select, highlight and zoom to them. Also supports picking an element inside a linked model by ID."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import ElementId, RevitLinkInstance, FilteredElementCollector, Reference
from System.Collections.Generic import List
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


def select_in_host(id_list):
    valid_ids = List[ElementId]()
    not_found = []
    for eid_int in id_list:
        eid = ElementId(eid_int)
        el = doc.GetElement(eid)
        if el is not None:
            valid_ids.Add(eid)
        else:
            not_found.append(eid_int)

    if valid_ids.Count == 0:
        forms.alert("Intha model-la intha ID(s) kedaikaла (not found in host model).\n\nLinked model IDs-a check pannانுமா? 'Search in Linked Model' option select pannunga.")
        return

    uidoc.Selection.SetElementIds(valid_ids)
    try:
        uidoc.ShowElements(valid_ids)
    except Exception:
        pass

    output.print_md("### Selected {0} element(s):".format(valid_ids.Count))
    for eid in valid_ids:
        el = doc.GetElement(eid)
        cat = el.Category.Name if el.Category else "N/A"
        output.print_md("- ID `{0}` — Category: **{1}** — Name/Type: {2}".format(
            eid.IntegerValue, cat, el.Name if hasattr(el, "Name") else ""))

    if not_found:
        forms.alert("Not found in host model: {0}".format(", ".join(str(x) for x in not_found)))


def select_in_link(id_list):
    links = FilteredElementCollector(doc).OfClass(RevitLinkInstance).ToElements()
    if not links:
        forms.alert("Model-la links illa.", exitscript=True)

    link_names = {}
    for l in links:
        try:
            name = l.Name
        except Exception:
            name = "Link {0}".format(l.Id.IntegerValue)
        link_names[name] = l

    link_choice = forms.SelectFromList.show(
        sorted(link_names.keys()), title="Select which Linked Model", multiselect=False
    )
    if not link_choice:
        return
    link_instance = link_names[link_choice]
    link_doc = link_instance.GetLinkDocument()
    if link_doc is None:
        forms.alert("Link load aagala (unloaded link). First load pannunga.", exitscript=True)

    refs = List[Reference]()
    not_found = []
    for eid_int in id_list:
        eid = ElementId(eid_int)
        el = link_doc.GetElement(eid)
        if el is not None:
            try:
                r = Reference(el).CreateLinkReference(link_instance)
                refs.Add(r)
            except Exception:
                not_found.append(eid_int)
        else:
            not_found.append(eid_int)

    if refs.Count == 0:
        forms.alert("Intha IDs link '{0}' -la kedaikaла.".format(link_choice))
        return

    uidoc.Selection.SetReferences(refs)
    output.print_md("### Selected {0} element(s) inside link '{1}':".format(refs.Count, link_choice))
    for eid_int in id_list:
        if eid_int not in not_found:
            output.print_md("- ID `{0}`".format(eid_int))

    if not_found:
        forms.alert("Not found in link: {0}".format(", ".join(str(x) for x in not_found)))


def main():
    where = forms.CommandSwitchWindow.show(
        ["Search in Host Model", "Search in Linked Model"],
        message="Where is the Element ID from?"
    )
    if not where:
        script.exit()

    id_input = forms.ask_for_string(
        default="", prompt="Enter Element ID(s) - comma or space separated:",
        title="Select By ID"
    )
    if not id_input:
        script.exit()

    raw_parts = id_input.replace(",", " ").split()
    id_list = []
    bad = []
    for p in raw_parts:
        try:
            id_list.append(int(p))
        except ValueError:
            bad.append(p)

    if bad:
        forms.alert("Ivai valid numbers illa, ignore pannuren: {0}".format(", ".join(bad)))

    if not id_list:
        forms.alert("Valid Element ID entered pannala.", exitscript=True)

    if where == "Search in Host Model":
        select_in_host(id_list)
    else:
        select_in_link(id_list)


if __name__ == "__main__":
    main()
