# -*- coding: utf-8 -*-
"""Get IDs of Selection - reverse of Select By ID. Select element(s) in the
model first, then run this to see their Element IDs, Category and Name/Type
in a popup list, with a one-click Copy All."""
__title__ = "Get\nIDs"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Shows Element ID, Category and Name/Type for the current selection in a popup list. Reverse of Select By ID."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")
clr.AddReference("System.Windows.Forms")

from Autodesk.Revit.DB import ElementId
from System.Windows import Window, Thickness, WindowStartupLocation, GridLength, GridUnitType
from System.Windows.Controls import (
    Grid as WGrid, RowDefinition, ColumnDefinition, ListView, GridView, GridViewColumn,
    Button, StackPanel, Orientation, TextBlock, ScrollBarVisibility
)
from System.Windows.Forms import Clipboard
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()


class RowItem(object):
    def __init__(self, eid, category, name):
        self.Id = eid
        self.Category = category
        self.Name = name


class GetIdsWindow(Window):
    def __init__(self, rows):
        Window.__init__(self)
        self.rows = rows
        self.Title = "Get IDs - {0} element(s) selected".format(len(rows))
        self.Width = 560
        self.Height = 480
        self.WindowStartupLocation = WindowStartupLocation.CenterScreen

        root = WGrid()
        root.Margin = Thickness(10)
        root.RowDefinitions.Add(RowDefinition())
        root.RowDefinitions.Add(RowDefinition())
        root.RowDefinitions[0].Height = GridLength(1, GridUnitType.Star)
        root.RowDefinitions[1].Height = GridLength(1, GridUnitType.Auto)

        lv = ListView()
        lv.SelectionMode = 1  # Extended-ish default is fine; not critical here
        gv = GridView()
        col1 = GridViewColumn()
        col1.Header = "Element ID"
        col1.Width = 110
        col1.DisplayMemberBinding = None
        col2 = GridViewColumn()
        col2.Header = "Category"
        col2.Width = 170
        col3 = GridViewColumn()
        col3.Header = "Name / Type"
        col3.Width = 220

        # bind using simple PropertyPath via Binding since IronPython objects
        # expose plain python attributes as CLR-visible properties is not
        # guaranteed; safer to set DisplayMemberBinding with System.Windows.Data.Binding
        from System.Windows.Data import Binding
        col1.DisplayMemberBinding = Binding("Id")
        col2.DisplayMemberBinding = Binding("Category")
        col3.DisplayMemberBinding = Binding("Name")

        gv.Columns.Add(col1)
        gv.Columns.Add(col2)
        gv.Columns.Add(col3)
        lv.View = gv
        lv.ItemsSource = rows
        WGrid.SetRow(lv, 0)
        root.Children.Add(lv)

        btn_panel = StackPanel()
        btn_panel.Orientation = Orientation.Horizontal
        btn_panel.Margin = Thickness(0, 8, 0, 0)

        btn_copy = Button()
        btn_copy.Content = "Copy All IDs"
        btn_copy.Width = 120
        btn_copy.Height = 28
        btn_copy.Margin = Thickness(0, 0, 8, 0)
        btn_copy.Click += self.on_copy
        btn_panel.Children.Add(btn_copy)

        btn_close = Button()
        btn_close.Content = "Close"
        btn_close.Width = 90
        btn_close.Height = 28
        btn_close.Click += self.on_close
        btn_panel.Children.Add(btn_close)

        WGrid.SetRow(btn_panel, 1)
        root.Children.Add(btn_panel)

        self.Content = root

    def on_copy(self, sender, args):
        ids_text = ", ".join(str(r.Id) for r in self.rows)
        try:
            Clipboard.SetText(ids_text)
            forms.alert("{0} ID(s) clipboard-ku copy aayiduchu.".format(len(self.rows)))
        except Exception:
            forms.alert("Clipboard copy panna mudiyala. IDs:\n\n{0}".format(ids_text))

    def on_close(self, sender, args):
        self.Close()


def main():
    sel_ids = list(uidoc.Selection.GetElementIds())
    if not sel_ids:
        forms.alert("Model-la eppadiyum oru element(s) select pannunga, appram indha tool run pannunga.", exitscript=True)

    rows = []
    for eid in sel_ids:
        el = doc.GetElement(eid)
        if el is None:
            continue
        cat = el.Category.Name if el.Category else "N/A"
        name = el.Name if hasattr(el, "Name") else ""
        rows.append(RowItem(eid.IntegerValue, cat, name))

    rows.sort(key=lambda r: r.Id)

    output.print_md("### Selected {0} element(s):".format(len(rows)))
    for r in rows:
        output.print_md("- ID `{0}` — Category: **{1}** — Name/Type: {2}".format(r.Id, r.Category, r.Name))

    win = GetIdsWindow(rows)
    win.ShowDialog()


if __name__ == "__main__":
    main()
