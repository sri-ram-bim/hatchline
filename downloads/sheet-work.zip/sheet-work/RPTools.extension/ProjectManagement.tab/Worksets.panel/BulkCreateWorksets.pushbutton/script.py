# -*- coding: utf-8 -*-
"""Bulk create Worksets from a plain text file - one workset name per line."""
__title__ = "Bulk Create\nWorksets"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Select a .txt file with one workset name per line -> creates all of them in bulk. Model must be workshared (or this tool will enable worksharing first, on your confirmation)."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import Transaction, Workset, WorksetTable, FilteredWorksetCollector, WorksetKind
from pyrevit import revit, forms, script

doc = revit.doc
output = script.get_output()


def get_existing_workset_names():
    worksets = FilteredWorksetCollector(doc).OfKind(WorksetKind.UserWorkset).ToWorksets()
    return set(w.Name for w in worksets)


def main():
    if not doc.IsWorkshared:
        enable = forms.alert(
            "Intha model workshared illa (Worksets enabled illa).\n\n"
            "Worksharing enable pannатுма? (This creates 'Shared Levels and Grids' + 'Workset1' automatically, standard Revit behavior.)",
            options=["Yes, Enable Worksharing", "Cancel"]
        )
        if enable != "Yes, Enable Worksharing":
            script.exit()
        t0 = Transaction(doc, "Enable Worksharing")
        t0.Start()
        try:
            doc.EnableWorksharing("Shared Levels and Grids", "Workset1")
            t0.Commit()
        except Exception as ex:
            t0.RollBack()
            forms.alert("Worksharing enable panna mудியала: {0}".format(str(ex)), exitscript=True)

    file_path = forms.pick_file(file_ext="txt", title="Select .txt file - one workset name per line")
    if not file_path:
        script.exit()

    with open(file_path, "r") as f:
        lines = [ln.strip() for ln in f.readlines()]
    workset_names = [ln for ln in lines if ln]

    if not workset_names:
        forms.alert("File-la workset names illa (empty file).", exitscript=True)

    existing = get_existing_workset_names()
    to_create = []
    already_exist = []
    for name in workset_names:
        if name in existing:
            already_exist.append(name)
        else:
            to_create.append(name)

    if not to_create:
        forms.alert("Ella worksets-um already irukku model-la. Puthusa onnum create pannala.")
        return

    output.print_md("### Worksets to create ({0}):".format(len(to_create)))
    for n in to_create:
        output.print_md("- {0}".format(n))
    if already_exist:
        output.print_md("### Already existing, skipped ({0}):".format(len(already_exist)))
        for n in already_exist:
            output.print_md("- {0}".format(n))

    t = Transaction(doc, "Bulk Create Worksets")
    t.Start()
    created = 0
    failed = []
    try:
        for name in to_create:
            try:
                Workset.Create(doc, name)
                created += 1
            except Exception as ex:
                failed.append("{0}: {1}".format(name, str(ex)))
        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error: {0}".format(str(ex)))
        return

    msg = "{0} worksets created successfully!".format(created)
    if already_exist:
        msg += "\n{0} already existed (skipped).".format(len(already_exist))
    if failed:
        msg += "\n\nFailed:\n" + "\n".join(failed)
    forms.alert(msg)


if __name__ == "__main__":
    main()
