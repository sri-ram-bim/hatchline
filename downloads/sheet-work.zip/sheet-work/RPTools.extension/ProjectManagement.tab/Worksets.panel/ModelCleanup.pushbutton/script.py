# -*- coding: utf-8 -*-
"""Model cleaning toolkit - checklist of common cleanup actions (ModPlus style)."""
__title__ = "Model\nCleanup"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Checklist based model cleanup: purge unused, delete CAD imports/links, unused view templates, unplaced rooms, unused line/fill patterns, empty groups."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import (
    FilteredElementCollector, Transaction, ImportInstance, View,
    BuiltInCategory, SpatialElement, FillPatternElement, LinePatternElement,
    Group, GroupType
)
from pyrevit import revit, forms, script

doc = revit.doc
output = script.get_output()


def delete_cad_imports():
    imports = FilteredElementCollector(doc).OfClass(ImportInstance).ToElements()
    count = 0
    for imp in imports:
        try:
            doc.Delete(imp.Id)
            count += 1
        except Exception:
            pass
    return count


def delete_unused_view_templates():
    all_views = FilteredElementCollector(doc).OfClass(View).ToElements()
    templates = [v for v in all_views if v.IsTemplate]
    used_template_ids = set()
    for v in all_views:
        if not v.IsTemplate:
            try:
                if v.ViewTemplateId and v.ViewTemplateId.IntegerValue != -1:
                    used_template_ids.add(v.ViewTemplateId.IntegerValue)
            except Exception:
                pass

    count = 0
    for tpl in templates:
        if tpl.Id.IntegerValue not in used_template_ids:
            try:
                doc.Delete(tpl.Id)
                count += 1
            except Exception:
                pass
    return count


def delete_unplaced_rooms():
    rooms = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms).WhereElementIsNotElementType().ToElements()
    count = 0
    for r in rooms:
        try:
            if r.Area == 0 or r.Location is None:
                doc.Delete(r.Id)
                count += 1
        except Exception:
            pass
    return count


def delete_unused_line_patterns():
    patterns = FilteredElementCollector(doc).OfClass(LinePatternElement).ToElements()
    count = 0
    for p in patterns:
        name = p.Name
        if name in ("Solid",):
            continue
        try:
            doc.Delete(p.Id)
            count += 1
        except Exception:
            pass
    return count


def delete_empty_groups():
    group_types = FilteredElementCollector(doc).OfClass(GroupType).ToElements()
    count = 0
    for gt in group_types:
        try:
            members = gt.Groups
            if members.Size == 0:
                doc.Delete(gt.Id)
                count += 1
        except Exception:
            pass
    return count


def purge_unused_native():
    """Uses Revit's built-in PurgeUnusedElements (Revit 2022+ API). Falls back gracefully if unavailable."""
    try:
        doc.PurgeUnusedElements(None)
        return True
    except Exception:
        return False


ACTIONS = {
    "Delete CAD Imports (linked/imported DWG-DXF-DGN in model)": delete_cad_imports,
    "Delete Unused View Templates": delete_unused_view_templates,
    "Delete Unplaced/Zero-Area Rooms": delete_unplaced_rooms,
    "Delete Unused Line Patterns": delete_unused_line_patterns,
    "Delete Empty Group Types (0 instances)": delete_empty_groups,
    "Purge Unused (native Revit purge, Revit 2022+)": None,  # handled separately
}


def main():
    choices = forms.SelectFromList.show(
        list(ACTIONS.keys()),
        title="Model Cleanup - select actions to run",
        button_name="Run Cleanup",
        multiselect=True
    )
    if not choices:
        script.exit()

    confirm = forms.alert(
        "Intha cleanup actions UNDO panna mudியாதுla sila cases-la (purge). "
        "Continue pannuматра, first model-a SAVE / BACKUP pannirукणumnu recommend pannuரேன்.\n\n"
        "Continue?",
        options=["Yes, Continue", "Cancel"]
    )
    if confirm != "Yes, Continue":
        script.exit()

    t = Transaction(doc, "Model Cleanup")
    t.Start()
    results = []
    try:
        for choice in choices:
            if "Purge Unused" in choice:
                ok = purge_unused_native()
                results.append("Purge Unused (native): {0}".format("Done" if ok else "Not available in this Revit version — use File > Purge Unused manually."))
                continue
            func = ACTIONS[choice]
            n = func()
            results.append("{0}: {1} removed".format(choice, n))
        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error during cleanup: {0}".format(str(ex)))
        return

    output.print_md("# Model Cleanup Results")
    for r in results:
        output.print_md("- " + r)

    forms.alert("Model Cleanup Mudinjuduchu!\n\n" + "\n".join(results))


if __name__ == "__main__":
    main()
