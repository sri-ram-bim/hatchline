# -*- coding: utf-8 -*-
"""Toggle Grids - shows/hides ALL grids in the active view with one click."""
__title__ = "Toggle\nGrids"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Show/Hide all grids in the active view in one click (acts like an on/off switch)."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import FilteredElementCollector, Grid, Transaction
from System.Collections.Generic import List
from Autodesk.Revit.DB import ElementId
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
active_view = doc.ActiveView
output = script.get_output()


def main():
    grids = list(FilteredElementCollector(doc, active_view.Id).OfClass(Grid).ToElements())
    if not grids:
        forms.alert("Indha view-la grids illa.", exitscript=True)

    # Decide ON/OFF based on the majority current state, so one click
    # consistently flips everything the same direction.
    hidden_count = sum(1 for g in grids if g.IsHidden(active_view))
    turning_on = hidden_count >= (len(grids) - hidden_count)  # majority hidden -> show them

    ids_hidden = List[ElementId]()
    ids_visible = List[ElementId]()
    for g in grids:
        if g.IsHidden(active_view):
            ids_hidden.Add(g.Id)
        else:
            ids_visible.Add(g.Id)

    t = Transaction(doc, "Toggle Grids (RPTools)")
    t.Start()
    try:
        if turning_on and ids_hidden.Count:
            active_view.UnhideElements(ids_hidden)
        elif not turning_on and ids_visible.Count:
            active_view.HideElements(ids_visible)
        t.Commit()
    except Exception:
        t.RollBack()
        raise

    output.print_md("### Toggle Grids - {0}".format("Shown" if turning_on else "Hidden"))
    output.print_md("{0} grid(s) affected in view '{1}'.".format(
        ids_hidden.Count if turning_on else ids_visible.Count, active_view.Name))


if __name__ == "__main__":
    main()
