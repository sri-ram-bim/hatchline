# -*- coding: utf-8 -*-
"""Flip grids quickly - flip direction and/or toggle bubble visibility at each end, single or bulk."""
__title__ = "Flip\nGrids"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Select grids (or run on ALL grids in the active view) and flip their direction and/or toggle bubble visibility at both ends - quick bulk action."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import (
    FilteredElementCollector, Grid, Transaction, DatumEnds
)
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
active_view = doc.ActiveView
output = script.get_output()


def get_selected_grids():
    sel_ids = uidoc.Selection.GetElementIds()
    grids = []
    for eid in sel_ids:
        el = doc.GetElement(eid)
        if isinstance(el, Grid):
            grids.append(el)
    return grids


def get_all_grids_in_view():
    return list(FilteredElementCollector(doc, active_view.Id).OfClass(Grid).ToElements())


class GridItem(forms.TemplateListItem):
    @property
    def name(self):
        return self.item.Name


def main():
    selected = get_selected_grids()

    if not selected:
        use_all = forms.alert(
            "Grids select pannala. Active view-la irukura ELLA grids-layum use pannатுma?\n\n"
            "(No grids selected. Use ALL grids in the active view instead?)",
            options=["Yes, use ALL grids in view", "Cancel - I'll select grids first"]
        )
        if use_all != "Yes, use ALL grids in view":
            script.exit()
        selected = get_all_grids_in_view()
        if not selected:
            forms.alert("Active view-la grids kедаikaла.", exitscript=True)
    else:
        pick_more = forms.alert(
            "{0} grids selected. Ithuvே use pannатுma, illa active view-la ella grids-layum use pannатுma?".format(len(selected)),
            options=["Use Selected Grids Only", "Use ALL Grids in View Instead"]
        )
        if pick_more == "Use ALL Grids in View Instead":
            selected = get_all_grids_in_view()

    action = forms.CommandSwitchWindow.show(
        [
            "Flip Direction (mirror the grid line)",
            "Toggle Bubble - Start End",
            "Toggle Bubble - End End",
            "Show Bubble Both Ends",
            "Hide Bubble Both Ends",
        ],
        message="Select action to apply to {0} grid(s):".format(len(selected))
    )
    if not action:
        script.exit()

    t = Transaction(doc, "Flip/Toggle Grids")
    t.Start()
    count = 0
    errors = []
    try:
        for g in selected:
            try:
                if action.startswith("Flip Direction"):
                    g.FlipCurve()

                elif action == "Toggle Bubble - Start End":
                    cur = g.IsBubbleVisibleInView(DatumEnds.End0, active_view)
                    if cur:
                        g.HideBubbleInView(DatumEnds.End0, active_view)
                    else:
                        g.ShowBubbleInView(DatumEnds.End0, active_view)

                elif action == "Toggle Bubble - End End":
                    cur = g.IsBubbleVisibleInView(DatumEnds.End1, active_view)
                    if cur:
                        g.HideBubbleInView(DatumEnds.End1, active_view)
                    else:
                        g.ShowBubbleInView(DatumEnds.End1, active_view)

                elif action == "Show Bubble Both Ends":
                    g.ShowBubbleInView(DatumEnds.End0, active_view)
                    g.ShowBubbleInView(DatumEnds.End1, active_view)

                elif action == "Hide Bubble Both Ends":
                    g.HideBubbleInView(DatumEnds.End0, active_view)
                    g.HideBubbleInView(DatumEnds.End1, active_view)

                count += 1
            except Exception as ex:
                errors.append("{0}: {1}".format(g.Name, str(ex)))

        t.Commit()
    except Exception as ex:
        t.RollBack()
        forms.alert("Error: {0}".format(str(ex)))
        return

    msg = "{0} grid(s) updated ({1}).".format(count, action)
    if errors:
        msg += "\n\nErrors:\n" + "\n".join(errors[:15])
    forms.alert(msg)


if __name__ == "__main__":
    main()
