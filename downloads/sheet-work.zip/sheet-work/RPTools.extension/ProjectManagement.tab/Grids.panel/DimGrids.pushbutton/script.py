# -*- coding: utf-8 -*-
"""Dim Grids - select grids (or use ALL grids in the active view), the tool
groups them by parallel direction, then for each group you pick 2 points to
place one dimension string across every grid in that group."""
__title__ = "Dim\nGrids"
__author__ = "Ramesh Prakash | rameshe280@gmail.com"
__doc__ = "Auto-dimension grids: groups selected/all grids by parallel direction, then you pick a line per group to place the dimension string."

import clr
clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import (
    FilteredElementCollector, Grid, Transaction, Line, Options,
    ReferenceArray
)
from Autodesk.Revit.UI.Selection import ObjectType
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc
active_view = doc.ActiveView
output = script.get_output()

PARALLEL_TOLERANCE = 0.02  # ~1 degree, dot-product based


def get_selected_grids():
    sel_ids = uidoc.Selection.GetElementIds()
    grids = []
    for eid in sel_ids:
        el = doc.GetElement(eid)
        if isinstance(el, Grid):
            grids.append(el)
    return grids


def get_all_grids_in_view():
    return list(FilteredElementCollector(doc, active_view.Id).OfClass(Grid).ToElements())


def get_curve_reference(grid):
    """Grab a geometric Reference to the grid's line so it can be used in a
    ReferenceArray for NewDimension - this is the standard technique since
    Grid doesn't expose a ready-made 'dimension reference' property."""
    opt = Options()
    opt.ComputeReferences = True
    opt.View = active_view
    geo = grid.get_Geometry(opt)
    if geo is None:
        return None
    for g in geo:
        if isinstance(g, Line):
            return g.Reference
    return None


def direction_key(grid):
    curve = grid.Curve
    d = curve.Direction
    # normalize so opposite-facing but parallel grids land in the same group
    if d.X < 0 or (abs(d.X) < 1e-9 and d.Y < 0):
        d = d.Negate()
    return d


def group_parallel(grids):
    groups = []  # list of (direction, [grids])
    for g in grids:
        d = direction_key(g)
        placed = False
        for gd, glist in groups:
            if abs(gd.DotProduct(d)) > 1 - PARALLEL_TOLERANCE:
                glist.append(g)
                placed = True
                break
        if not placed:
            groups.append((d, [g]))
    return groups


def main():
    grids = get_selected_grids()
    source_label = "selection ({0} grid(s))".format(len(grids))
    if not grids:
        choice = forms.CommandSwitchWindow.show(
            ["Use ALL grids in active view", "Cancel"],
            message="Grids select pannala. Enna pannanum?"
        )
        if choice != "Use ALL grids in active view":
            script.exit()
        grids = get_all_grids_in_view()
        source_label = "active view ({0} grid(s))".format(len(grids))

    if not grids:
        forms.alert("Dimension pannradhukku grids kedaikala.", exitscript=True)

    groups = group_parallel(grids)
    output.print_md("### Dim Grids - {0}".format(source_label))
    output.print_md("{0} parallel group(s) found.".format(len(groups)))

    done_groups = 0
    for idx, (direction, glist) in enumerate(groups, start=1):
        if len(glist) < 2:
            output.print_md("- Group {0}: only 1 grid ('{1}') - skip pannuren (dimension-ku kuraindhathu 2 venum).".format(
                idx, glist[0].Name))
            continue

        names = ", ".join(g.Name for g in glist)
        try:
            pt1 = uidoc.Selection.PickPoint(
                "Group {0}/{1} ({2} grids: {3}) - dimension line START point pick pannunga".format(
                    idx, len(groups), len(glist), names))
            pt2 = uidoc.Selection.PickPoint(
                "Group {0}/{1} - dimension line END point pick pannunga".format(idx, len(groups)))
        except OperationCanceledException:
            output.print_md("- Group {0}: user cancel pannirar - skip.".format(idx))
            continue

        ref_array = ReferenceArray()
        missing = []
        for g in glist:
            ref = get_curve_reference(g)
            if ref is not None:
                ref_array.Append(ref)
            else:
                missing.append(g.Name)

        if ref_array.Size < 2:
            output.print_md("- Group {0}: valid curve references kuraivu - skip.".format(idx))
            continue

        t = Transaction(doc, "Dim Grids (RPTools)")
        t.Start()
        try:
            dim_line = Line.CreateBound(pt1, pt2)
            doc.Create.NewDimension(active_view, dim_line, ref_array)
            t.Commit()
            done_groups += 1
            output.print_md("- Group {0}: dimension created across {1} grid(s).".format(idx, ref_array.Size))
            if missing:
                output.print_md("  (Reference kedaikala: {0})".format(", ".join(missing)))
        except Exception as ex:
            t.RollBack()
            output.print_md("- Group {0}: FAILED - {1}".format(idx, str(ex)))

    forms.alert("Dim Grids mudinjuduchu.\n\n{0} of {1} group(s) dimension pannirichu.".format(
        done_groups, len(groups)))


if __name__ == "__main__":
    main()
