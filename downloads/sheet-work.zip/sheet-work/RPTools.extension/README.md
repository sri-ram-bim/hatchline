# RP Tools - pyRevit Extension

**Developed by:** Ramesh Prakash
**Email:** rameshe280@gmail.com

A full "Project Management" toolset for Revit, built on pyRevit, covering batch export, sheet management, element lookup, model cleanup, worksets and grid tools — inspired by DiRoots ProSheets, Archilizer, ModPlus and pyRevit Quickly.

## Tab / Panel Structure

```
RPTools.extension/
└── ProjectManagement.tab/
    ├── Export.panel/
    │   └── Batch Export           - PDF/DWG batch export, custom naming
    ├── Sheets.panel/
    │   ├── Sheets From Views      - bulk-create sheets from selected views
    │   ├── Align Viewports        - align selected viewports on a sheet
    │   ├── Copy/Move Legends      - copy or move legend/viewports to many sheets
    │   └── Bulk Rename Sheets     - find&replace / prefix-suffix / CSV import rename
    ├── Selection.panel/
    │   └── Select By ID           - select/zoom element(s) by ID, host or linked model
    ├── Worksets.panel/
    │   ├── Model Cleanup          - checklist-based cleanup (ModPlus style)
    │   └── Bulk Create Worksets   - create worksets in bulk from a .txt list
    └── Grids.panel/
        └── Flip Grids             - flip direction / toggle bubble ends in bulk
```

## Installation

1. Extract this zip anywhere, e.g. `D:\RevitTools\RPTools.extension`
2. Open Revit → **pyRevit tab → Settings → Custom Extension Directories → Add Folder**
3. Point it to the **parent folder** that contains `RPTools.extension` (not the `.extension` folder itself)
4. Click **Save Settings & Reload** (or restart Revit)
5. A new tab **"ProjectManagement"** appears with 5 panels and 9 tools

> Alternative: copy the whole `RPTools.extension` folder directly into
> `%APPDATA%\pyRevit\Extensions\` then Reload pyRevit.

## Tool-by-Tool Guide

### 1. Batch Export
Select sheets → choose PDF/DWG/both → choose naming pattern (`Number - Name`, `Number_Name`, `Name only`, `Number only`) → choose combined or per-sheet PDF → pick output folder → exports with a progress log.

### 2. Sheets From Views
Select views → pick a titleblock → enter a starting sheet number (e.g. `A-101`, auto-increments) → creates one sheet per view with the view placed at a default center point. Adjust exact position per sheet afterward if needed. **Note:** Legends and Schedules can go on multiple sheets; regular views (plans/sections/elevations/3D) can only be on ONE sheet — if a view is already placed somewhere, it will be skipped with a note.

### 3. Align Viewports
Open a sheet → select 2+ viewports (Ctrl-click or box select) → run tool → choose alignment mode (Left/Right/Top/Bottom/Center-H/Center-V). All selected viewports align to the **first one you selected**.

### 4. Copy/Move Legends & Viewports
Open a sheet → select legend viewport(s) (or any viewport) → run tool → pick target sheets from a list → choose Copy or Move. The tool places the view at the same position on every target sheet. **Note:** only Legend views can repeat on multiple sheets — a normal view can only be placed once anywhere in the whole model (standard Revit rule).

### 5. Bulk Rename Sheets
Three modes:
- **Find & Replace** — pick field (Number/Name), enter find + replace text, applies to sheets you select from a list
- **Add Prefix/Suffix** — pick field, enter prefix and/or suffix
- **Import Mapping CSV** — pick a `.csv` file formatted as:
  ```
  OldNumber,NewNumber,NewName
  A-101,A-201,Ground Floor Plan
  A-102,A-202,First Floor Plan
  ```
  Leave `NewNumber` or `NewName` blank in a row to keep that field unchanged.

### 6. Select By ID
Choose **Host Model** or **Linked Model** → enter one or more Element IDs (comma or space separated) → tool selects, highlights, and zooms to them in the current view, and prints a small table of Category/Name for each found element.

### 7. Model Cleanup
Checklist of cleanup actions you can multi-select before running:
- Delete CAD Imports (imported/linked DWG-DXF-DGN geometry in the model)
- Delete Unused View Templates
- Delete Unplaced / Zero-Area Rooms
- Delete Unused Line Patterns
- Delete Empty Group Types (0 instances placed)
- Purge Unused (uses Revit's native `Document.PurgeUnusedElements()`, available Revit 2022+; on older versions it will tell you to use **File > Purge Unused** manually)

⚠️ **Backup your model before running cleanup** — some actions are not easily undoable once saved/synced.

### 8. Bulk Create Worksets
Prepare a plain `.txt` file with **one workset name per line**, e.g.:
```
Architecture
Structure
Electrical
Mechanical
Plumbing
Shared Levels and Grids
```
Run the tool → if the model isn't workshared yet, it asks to enable worksharing first → pick your `.txt` file → tool creates every workset that doesn't already exist, and reports which ones were skipped (already existing) or failed.

### 9. Flip Grids
Select grids on screen first (optional) → run tool → choose "use selected" or "use ALL grids in active view" → pick an action:
- Flip Direction (mirrors the grid line, like `FlipCurve`)
- Toggle Bubble - Start End / End End
- Show Bubble Both Ends
- Hide Bubble Both Ends

## Requirements
- pyRevit installed (4.8+ recommended)
- Revit 2021–2025 (a few features like native Purge Unused need Revit 2022+; the tool degrades gracefully on older versions with a message instead of crashing)

## Notes for future updates
Ovvoru tool thani `.pushbutton` folder-la irukku (`script.py` + `bundle.yaml`) — so future-la edhavadhu tool matum update pannanumnа, andha folder mattum edit pannunga, remaining tools affect aagatha. Puthusa tool add pannanumnа, same pattern-la `SomeName.pushbutton` folder create pannі `script.py` + `bundle.yaml` podunga, pyRevit automatic-a detect pannідும் oru Reload panninathum.

Kேட்கும் features (specific workset export setups, DWG layer mapping presets, more model cleanup checks, viewport dimension-alignment tools, etc.) irundhа sollunga — indha same extension-oda add pannலாம்.
